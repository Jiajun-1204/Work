import { Routes, Route } from "react-router-dom";
import Home from "@/pages/Home";
import { useState } from "react";
import { AuthContext } from '@/contexts/authContext';
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import InjectionMolding from "@/pages/InjectionMolding";
import MoldStructure from "@/pages/MoldStructure";
import ProcessingTechnology from "@/pages/ProcessingTechnology";
import MaterialsDatabase from "@/pages/MaterialsDatabase";
import LearningTools from "@/pages/LearningTools";
import KnowledgeQuiz from "@/pages/KnowledgeQuiz";

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);

  const logout = () => {
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider
      value={{ isAuthenticated, setIsAuthenticated, logout }}
    >
      <Navbar />
      <main className="min-h-screen">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/injection-molding" element={<InjectionMolding />} />
          <Route path="/mold-structure" element={<MoldStructure />} />
          <Route path="/processing-technology" element={<ProcessingTechnology />} />
          <Route path="/materials-database" element={<MaterialsDatabase />} />
          <Route path="/learning-tools" element={<LearningTools />} />
          <Route path="/knowledge-quiz" element={<KnowledgeQuiz />} />
        </Routes>
      </main>
      <Footer />
    </AuthContext.Provider>
  );
}
