import { Link } from 'react-router-dom';
import { faGithub, faLinkedin, faTwitter } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center text-white">
                <i className="fa-solid fa-industry"></i>
              </div>
              <span className="text-lg font-bold text-white">模具学习平台</span>
            </div>
            <p className="mb-4 text-gray-400">
              提供全面的模具工程知识体系，从基础原理到高级应用，助力您成为模具行业专家。
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
                <faGithub size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
                <faLinkedin size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
                <faTwitter size={20} />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">学习资源</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/injection-molding" className="text-gray-400 hover:text-white transition-colors duration-200">
                  注塑成型原理
                </Link>
              </li>
              <li>
                <Link to="/mold-structure" className="text-gray-400 hover:text-white transition-colors duration-200">
                  模具结构与零件
                </Link>
              </li>
              <li>
                <Link to="/processing-technology" className="text-gray-400 hover:text-white transition-colors duration-200">
                  加工工艺
                </Link>
              </li>
              <li>
                <Link to="/materials-database" className="text-gray-400 hover:text-white transition-colors duration-200">
                  材料数据库
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">工具与服务</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/learning-tools" className="text-gray-400 hover:text-white transition-colors duration-200">
                  学习工具
                </Link>
              </li>
              <li>
                <Link to="/knowledge-quiz" className="text-gray-400 hover:text-white transition-colors duration-200">
                  知识测验
                </Link>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
                  专家咨询
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
                  培训课程
                </a>
              </li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold text-white mb-4">联系我们</h3>
            <ul className="space-y-2">
              <li className="flex items-center">
                <i className="fa-solid fa-envelope mr-2 text-gray-400"></i>
                <span className="text-gray-400">contact@moldlearning.com</span>
              </li>
              <li className="flex items-center">
                <i className="fa-solid fa-phone mr-2 text-gray-400"></i>
                <span className="text-gray-400">+86 123 4567 8910</span>
              </li>
              <li className="flex items-center">
                <i className="fa-solid fa-map-marker-alt mr-2 text-gray-400"></i>
                <span className="text-gray-400">中国上海市浦东新区</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-10 pt-6 border-t border-gray-800 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm">
            &copy; {new Date().getFullYear()} 模具学习平台. 保留所有权利.
          </p>
          <div className="mt-4 md:mt-0 flex space-x-6">
            <a href="#" className="text-gray-500 hover:text-gray-300 text-sm">
              隐私政策
            </a>
            <a href="#" className="text-gray-500 hover:text-gray-300 text-sm">
              使用条款
            </a>
            <a href="#" className="text-gray-500 hover:text-gray-300 text-sm">
              Cookie 政策
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}