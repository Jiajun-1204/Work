import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/Tabs';

export default function MoldStructure() {
  const { isDark } = useTheme();
  const [activeModule, setActiveModule] = useState('cavity');
  const [selectedPart, setSelectedPart] = useState<string | null>(null);
  const [isExploded, setIsExploded] = useState(false);
  const modelRef = useRef<HTMLDivElement>(null);

  // 模具模块数据
  const modules = {
    cavity: {
      title: "型腔部分",
      description: "型腔是模具中直接形成制品形状的部分，包括上下内模、镶件等组件。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=mold%20cavity%20components%2C%20core%20and%20cavity%2C%203D%20structure&sign=018e5bac642eaae90f601ae906245e96",
      parts: [
        {
          id: "upper_core",
          name: "上内模",
          description: "模具的固定部分，与定模座板相连，形成制品的外表面。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=upper%20core%20mold%20component%2C%20close-up%20view&sign=7a899ad34bb16676e12dc5362ab30c43",
          issues: [
            "表面磨损：影响制品表面质量，需定期抛光或更换",
            "淬火变形：导致合模不良，需严格控制热处理工艺"
          ]
        },
        {
          id: "lower_core",
          name: "下内模",
          description: "模具的移动部分，与动模座板相连，形成制品的内表面。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=lower%20core%20mold%20component%2C%20close-up%20view&sign=219db9c605ac1054bc476c622aea816c",
          issues: [
            "顶针痕迹：影响制品外观，需优化顶针设计和位置",
            "粘模现象：导致制品难以脱模，需增加脱模斜度或使用脱模剂"
          ]
        },
        {
          id: "insert",
          name: "镶件",
          description: "嵌入模具型腔中的可拆卸部件，用于形成制品的复杂形状或便于维修。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=mold%20insert%20component%2C%20close-up%20view&sign=9d9a2c6958a609bd36c8ce50fa0eb482",
          issues: [
            "配合间隙：间隙过大会导致飞边，过小会导致装配困难",
            "定位不准：导致制品尺寸偏差，需确保定位销精度"
          ]
        },
        {
          id: "angle_lifter",
          name: "斜顶",
          description: "用于成型制品内侧倒扣的机构，在顶出过程中同时完成侧抽芯动作。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=angle%20lifter%20mold%20component%2C%20close-up%20view&sign=8e04eb70a7fb6d7bc483d1f192dcdc2f",
          issues: [
            "卡滞现象：导致动作不顺畅，需保证配合精度和润滑",
            "磨损过快：影响使用寿命，需选择合适的材料和热处理工艺"
          ]
        },
        {
          id: "slide",
          name: "行位",
          description: "用于成型制品外侧倒扣的机构，通过斜导柱或液压缸驱动完成侧抽芯动作。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=slide%20mold%20component%2C%20close-up%20view&sign=36dafe1e82e3ccf9b601cb6f0a142f70",
          issues: [
            "抽芯力不足：导致制品变形或拉伤，需增加驱动力量",
            "定位不稳定：导致制品尺寸偏差，需优化定位机构"
          ]
        }
      ]
    },
    base: {
      title: "模架系统",
      description: "模架是模具的骨架，支撑和固定模具的各个部件，保证模具的精度和稳定性。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=mold%20base%20system%2C%20frame%20structure%2C%203D%20view&sign=afdf25f927892f0ee694633322aeef41",
      parts: [
        {
          id: "fixed_plate",
          name: "定模座板",
          description: "模具的固定部分，与注塑机的定模板相连，支撑定模部分的所有组件。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=fixed%20mold%20plate%2C%20close-up%20view&sign=a6c45cc28cd533696394d36e5f085d6d",
          issues: [
            "变形：导致模具精度下降，需选择足够厚度和强度的材料",
            "螺丝松动：导致模具移位，需定期检查并紧固"
          ]
        },
        {
          id: "moving_plate",
          name: "动模座板",
          description: "模具的移动部分，与注塑机的动模板相连，支撑动模部分的所有组件。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=moving%20mold%20plate%2C%20close-up%20view&sign=2376c1ccee93b9b0d1d92651bccc6400",
          issues: [
            "顶出孔磨损：导致顶出动作不顺畅，需增加耐磨衬套",
            "安装面精度：影响模具开合模精度，需保证平面度和平行度"
          ]
        },
        {
          id: "guide_pillar",
          name: "导柱导套",
          description: "保证动模和定模精确导向和定位的部件，防止模具合模时错位。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=guide%20pillar%20and%20bushing%2C%20close-up%20view&sign=3dd8a45d5b488771db24080b405327cb",
          issues: [
            "磨损：导致导向精度下降，需定期润滑和更换",
            "拉伤：导致模具无法正常开合，需避免异物进入和保证清洁"
          ]
        },
        {
          id: "support_block",
          name: "支撑块",
          description: "在动模座板和动模板之间形成顶出机构的空间，同时承受注射压力。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=support%20block%20mold%20component%2C%20close-up%20view&sign=632bb2c0f8eacb6d59c931397721c4fb",
          issues: [
            "变形：导致模具精度下降，需选择高强度材料",
            "高度误差：导致顶出距离不准确，需严格控制加工精度"
          ]
        }
      ]
    },
    runner: {
      title: "流道系统",
      description: "流道系统是塑料熔体从注塑机射嘴进入模具型腔的通道，包括主流道、分流道和进浇口。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=runner%20system%2C%20sprue%20and%20gates%2C%203D%20view&sign=ca587ed4986b61f94d0e62e8b7145720",
      parts: [
        {
          id: "sprue_bushing",
          name: "唧嘴",
          description: "连接注塑机射嘴和主流道的部件，保证塑料熔体顺利进入模具。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=sprue%20bushing%20mold%20component%2C%20close-up%20view&sign=941b905acf9ee62a0be7219e357f31c1",
          issues: [
            "漏料：导致塑料溢出，需检查与射嘴的配合和密封",
            "磨损：导致流道表面粗糙，影响熔体流动，需定期更换"
          ]
        },
        {
          id: "main_runner",
          name: "主流道",
          description: "从唧嘴到分流道的一段流道，通常设计为圆锥形，便于脱模。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=main%20runner%20mold%20component%2C%20close-up%20view&sign=84c14bb7e33acd125f058e3c688a47df",
          issues: [
            "冷料斑：影响制品质量，需在主流道末端设置冷料井",
            "剪切发热：导致材料降解，需优化流道尺寸和形状"
          ]
        },
        {
          id: "sub_runner",
          name: "分流道",
          description: "从主流道到各个浇口的流道，通常设计为圆形、梯形或半圆形截面。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=sub%20runner%20mold%20component%2C%20close-up%20view&sign=cbf298483f48e8e70ecb32f47abeec3a",
          issues: [
            "流动不平衡：导致各型腔填充不一致，需优化流道布局",
            "压力损失：影响填充效果，需合理设计流道尺寸和长度"
          ]
        },
        {
          id: "gate",
          name: "进浇口",
          description: "连接分流道和型腔的部分，是控制熔体进入型腔的关键部位。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=gate%20mold%20component%2C%20close-up%20view&sign=802852066b3e326dd53b7a9e9e0303f2",
          issues: [
            "浇口痕迹：影响制品外观，需选择合适的浇口类型和位置",
            "冻结时间：影响保压效果，需优化浇口尺寸"
          ]
        }
      ]
    },
    cooling: {
      title: "冷却系统",
      description: "冷却系统通过循环冷却水带走模具热量，控制模具温度，保证制品质量和生产效率。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=cooling%20system%2C%20water%20channels%2C%203D%20view&sign=94e420f0d4ce86159a8d7f6b5348ecda",
      parts: [
        {
          id: "water_channel",
          name: "冷却水道",
          description: "模具内部的通道，用于流通冷却水，带走热量，控制模具温度。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=cooling%20water%20channels%2C%20close-up%20view&sign=48d709aea40e784763539efd868e78b2",
          issues: [
            "水垢堵塞：影响冷却效果，需定期清理和使用软化水",
            "冷却不均匀：导致制品变形，需优化水道布局和直径"
          ]
        },
        {
          id: "water_connector",
          name: "管接头",
          description: "连接模具冷却水道和外部冷却系统的部件，保证冷却水的密封循环。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=water%20connector%20mold%20component%2C%20close-up%20view&sign=85e41c54f99051f13288f5ceb9b2c45b",
          issues: [
            "漏水：导致冷却效果下降和生产环境恶化，需定期检查和更换密封件",
            "堵塞：导致冷却水流不畅，需定期清理"
          ]
        },
        {
          id: "隔水片",
          name: "隔水片",
          description: "在冷却水道中引导水流方向的部件，提高冷却效率和均匀性。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=water%20seal%20mold%20component%2C%20close-up%20view&sign=3477a2d0892ab3f840902631f205f83b",
          issues: [
            "密封不良：导致水流短路，影响冷却效果，需确保安装正确和密封件完好",
            "腐蚀：导致隔水片失效，需选择耐腐蚀材料"
          ]
        },
        {
          id: "temperature_controller",
          name: "温控器",
          description: "控制模具温度的设备，通过调节冷却水流量和温度，保证模具温度稳定。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=temperature%20controller%20equipment%2C%20close-up%20view&sign=817b977ca1fb7dda2036e7be2222532a",
          issues: [
            "温度波动：影响制品质量，需定期校准和维护",
            "传感器故障：导致温度控制失效，需定期检查和更换"
          ]
        }
      ]
    },
    ejection: {
      title: "脱模系统",
      description: "脱模系统用于将成型后的制品从模具型腔中推出，包括顶针、司筒、顶出板等部件。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=ejection%20system%2C%20ejector%20pins%2C%203D%20view&sign=72b6da1396063928e39472cb27718231",
      parts: [
        {
          id: "ejector_pin",
          name: "顶针",
          description: "最常用的顶出元件，通过注塑机的顶出机构推动，将制品从型腔中推出。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=ejector%20pin%20mold%20component%2C%20close-up%20view&sign=4bf29d19d4d5cff504c2e4bdc8d83a2e",
          issues: [
            "弯曲断裂：导致顶出失效，需选择合适直径和材料",
            "磨损：导致配合间隙增大，产生飞边，需定期更换"
          ]
        },
        {
          id: "ejector_sleeve",
          name: "司筒",
          description: "用于成型制品上的圆柱孔或轴类结构，由司筒和芯针组成。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=ejector%20sleeve%20mold%20component%2C%20close-up%20view&sign=82b04c9fb98f22666204b96b0743a295",
          issues: [
            "卡死：导致动作不顺畅，需保证配合精度和润滑",
            "芯针弯曲：导致制品孔位偏差，需增加芯针强度"
          ]
        },
        {
          id: "ejector_plate",
          name: "顶出板",
          description: "固定顶针、司筒等顶出元件的板，在注塑机顶出机构的推动下完成顶出动作。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=ejector%20plate%20mold%20component%2C%20close-up%20view&sign=1092d3bb517256c81afff3574539e88e",
          issues: [
            "复位不良：导致模具无法正常合模，需检查复位机构和弹簧",
            "变形：导致顶出不平衡，需选择足够强度的材料"
          ]
        },
        {
          id: "return_pin",
          name: "回针",
          description: "在合模时推动顶出板复位的部件，保证顶出机构回到初始位置。",
          image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=return%20pin%20mold%20component%2C%20close-up%20view&sign=77038bc36e7f2313cff6c26ba942467b",
          issues: [
            "磨损：导致复位不精确，需定期更换",
            "弯曲：导致顶出板倾斜，需保证安装精度"
          ]
        }
      ]
    }
  };

  // 模拟3D模型爆炸效果
  const handleExplodeToggle = () => {
    setIsExploded(!isExploded);
    if (modelRef.current) {
      if (isExploded) {
        modelRef.current.style.transform = 'scale(1)';
      } else {
        modelRef.current.style.transform = 'scale(1.05)';
      }
    }
  };

  // 选择零件时的动画效果
  useEffect(() => {
    if (selectedPart && modelRef.current) {
      modelRef.current.style.opacity = '0.7';
      setTimeout(() => {
        if (modelRef.current) {
          modelRef.current.style.opacity = '1';
        }
      }, 300);
    }
  }, [selectedPart]);

  return (
    <div className="min-h-screen pt-24 pb-16 bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-200">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto mb-12 text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400">
            模具结构与零件图解系统
          </h1><p className="text-lg text-gray-600 dark:text-gray-400">
            探索模具各功能模块的结构、零件及其工作原理
          </p>
        </div>

        {/* 主内容区域 */}
        <Tabs defaultValue="cavity" className="w-full" onValueChange={setActiveModule}>
          <div className="flex justify-center mb-8">
            <TabsList className={`p-1 rounded-xl ${isDark ? 'bg-gray-800' : 'bg-gray-100'}`}>
              <TabsTrigger 
                value="cavity" 
                className={`px-6 py-2 rounded-lg transition-all duration-300 ${
                  activeModule === 'cavity' 
                    ? 'bg-blue-600 text-white font-medium' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                型腔部分
              </TabsTrigger>
              <TabsTrigger 
                value="base" 
                className={`px-6 py-2 rounded-lg transition-all duration-300 ${
                  activeModule === 'base' 
                    ? 'bg-blue-600 text-white font-medium' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                模架系统
              </TabsTrigger>
              <TabsTrigger 
                value="runner" 
                className={`px-6 py-2 rounded-lg transition-all duration-300 ${
                  activeModule === 'runner' 
                    ? 'bg-blue-600 text-white font-medium' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                流道系统
              </TabsTrigger>
              <TabsTrigger 
                value="cooling" 
                className={`px-6 py-2 rounded-lg transition-all duration-300 ${
                  activeModule === 'cooling' 
                    ? 'bg-blue-600 text-white font-medium' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                冷却系统
              </TabsTrigger>
              <TabsTrigger 
                value="ejection" 
                className={`px-6 py-2 rounded-lg transition-all duration-300 ${
                  activeModule === 'ejection' 
                    ? 'bg-blue-600 text-white font-medium' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                脱模系统
              </TabsTrigger>
            </TabsList>
          </div>

          {/* 各模块内容 */}
          {Object.keys(modules).map((key) => (
            <TabsContent key={key} value={key} className="mt-0">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="grid grid-cols-1 lg:grid-cols-2 gap-8"
              >
                {/* 左侧：模块概览和3D模型 */}
                <div>
                  <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} h-full`}>
                    <h2 className="text-2xl font-bold mb-4">{modules[key as keyof typeof modules].title}</h2>
                    <p className="text-gray-600 dark:text-gray-400 mb-6">
                      {modules[key as keyof typeof modules].description}
                    </p>
                    
                    {/* 3D模型展示 */}
                    <div className="relative rounded-lg overflow-hidden mb-6" style={{ height: '300px' }}>
                      <div 
                        ref={modelRef}
                        className="absolute inset-0 bg-gradient-to-b from-gray-200 to-gray-300 dark:from-gray-700 dark:to-gray-800 transition-all duration-500"
                        style={{ 
                          backgroundImage: `url(${modules[key as keyof typeof modules].image})`,
                          backgroundSize: 'cover',
                          backgroundPosition: 'center'
                        }}
                      ></div>
                      <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center">
                        <button
                          onClick={handleExplodeToggle}
                          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all duration-300 shadow-md"
                        >
                          {isExploded ? '合模视图' : '爆炸视图'}
                        </button>
                        <button className="p-2 bg-white/90 dark:bg-gray-800/90 hover:bg-white dark:hover:bg-gray-700 rounded-full transition-all duration-300 shadow-md">
                          <i className="fa-solid fa-arrows-rotate"></i>
                        </button>
                      </div>
                    </div>
                    
                    {/* 操作按钮 */}
                    <div className="grid grid-cols-2 gap-4">
                      <button className="py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all duration-300">
                        <i className="fa-solid fa-play mr-2"></i> 观看动画演示
                      </button>
                      <button className="py-3 px-4 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-all duration-300">
                        <i className="fa-solid fa-vr-cardboard mr-2"></i> 3D交互模型
                      </button>
                    </div>
                  </div>
                </div>
                
                {/* 右侧：零件列表和详情 */}
                <div>
                  <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} h-full`}>
                    <h3 className="text-xl font-bold mb-4">核心零件</h3>
                    
                    {/* 零件列表 */}
                    <div className="space-y-3 mb-6 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                      {modules[key as keyof typeof modules].parts.map((part) => (
                        <motion.div
                          key={part.id}
                          whileHover={{ scale: 1.01 }}
                          onClick={() => setSelectedPart(part.id)}
                          className={`p-3 rounded-lg cursor-pointer transition-all duration-300 ${
                            selectedPart === part.id
                              ? 'bg-blue-600 text-white shadow-md'
                              : isDark 
                                ? 'bg-gray-700 hover:bg-gray-600' 
                                : 'bg-gray-100 hover:bg-gray-200'
                          }`}
                        >
                          <div className="flex items-center">
                            <img 
                              src={part.image} 
                              alt={part.name}
                              className="w-12 h-12 object-cover rounded-lg mr-3"
                            />
                            <span className="font-medium">{part.name}</span>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                    
                    {/* 零件详情 */}
                    <AnimatePresence mode="wait">
                      {selectedPart ? (
                        <motion.div
                          key={selectedPart}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          exit={{ opacity: 0, y: -10 }}
                          transition={{ duration: 0.3 }}
                          className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}
                        >
                          {(() => {
                            const part = modules[key as keyof typeof modules].parts.find(
                              p => p.id === selectedPart
                            );
                            if (!part) return null;
                            
                            return (
                              <>
                                <h4 className="text-lg font-semibold mb-2">{part.name}</h4>
                                <p className="text-gray-600 dark:text-gray-400 mb-4">
                                  {part.description}
                                </p>
                                <h5 className="font-medium mb-2">常见问题及解决方案：</h5>
                                <ul className="space-y-2">
                                  {part.issues.map((issue, index) => (
                                    <li key={index} className="flex items-start">
                                      <i className="fa-solid fa-exclamation-circle text-amber-500 mt-1 mr-2"></i>
                                      <span className="text-gray-600 dark:text-gray-400">{issue}</span>
                                    </li>
                                  ))}
                                </ul>
                              </>
                            );
                          })()}
                        </motion.div>
                      ) : (
                        <div className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'} text-center`}>
                          <p className="text-gray-500 dark:text-gray-400">请选择一个零件查看详情</p>
                        </div>
                      )}
                    </AnimatePresence>
                  </div>
                </div>
              </motion.div>
            </TabsContent>
          ))}
        </Tabs>
        
        {/* 学习提示 */}
        <div className="mt-12">
          <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800/80' : 'bg-white'} border-l-4 border-blue-600`}>
            <h3 className="text-xl font-bold mb-3">学习提示</h3>
            <p className="text-gray-600 dark:text-gray-400">
              理解模具各部分的结构和功能是掌握注塑成型技术的基础。建议您结合3D模型和动画演示，深入了解各零件之间的装配关系和工作原理。在实际工作中，熟悉模具结构有助于快速解决生产中遇到的问题，提高模具设计和维护的效率。
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}