import { useState } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function ProcessingTechnology() {
  const { isDark } = useTheme();
  const [activeProcess, setActiveProcess] = useState('cnc');
  
  // 成本效益分析数据
  const costBenefitData = [
    { name: 'CNC加工', 精度: 85, 成本: 75, 效率: 80, 适用范围: 90 },
    { name: '电火花加工', 精度: 95, 成本: 65, 效率: 60, 适用范围: 75 },
    { name: '线切割加工', 精度: 90, 成本: 70, 效率: 65, 适用范围: 70 },
    { name: '磨削加工', 精度: 95, 成本: 60, 效率: 70, 适用范围: 65 },
    { name: '抛光加工', 精度: 90, 成本: 55, 效率: 50, 适用范围: 60 },
  ];
  
  // 加工工艺数据
  const processes = {
    cnc: {
      title: "CNC加工",
      description: "数控加工是模具制造中最常用的加工方式，通过计算机控制机床进行精确的铣削、钻孔、镗孔等操作。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=CNC%20milling%20machine%2C%20mold%20manufacturing%2C%20precision%20machining&sign=765d82896b74a29147fbd4a995f3da9f",
      features: [
        { title: "加工范围", content: "适用于各种模具零件的平面、曲面、孔系等复杂形状加工" },
        { title: "精度控制", content: "通常可达±0.01mm，高精度机床可达±0.005mm" },
        { title: "刀具选择", content: "根据材料和加工要求选择不同类型的刀具，如立铣刀、球头刀、钻头等" },
        { title: "编程要点", content: "合理设置切削参数、刀具路径，避免过切和欠切" },
      ],
      applications: [
        "模具型腔和型芯的粗加工和半精加工",
        "模架零件的加工",
        "电极的加工",
        "各种复杂形状的模具零件加工"
      ]
    },
    edm: {
      title: "电火花加工(EDM)",
      description: "电火花加工是通过电极与工件之间的脉冲放电产生的高温来蚀除金属的加工方法，特别适合加工复杂形状的模具零件。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=EDM%20machine%2C%20electrical%20discharge%20machining%2C%20mold%20manufacturing&sign=dc3315e24d424f502cabc30661b5f694",
      features: [
        { title: "放电原理", content: "利用脉冲放电时的高温(10000°C以上)使金属熔化和汽化，从而蚀除材料" },
        { title: "电极设计", content: "电极材料通常为铜或石墨，设计时需考虑放电间隙、损耗补偿等因素" },
        { title: "表面粗糙度", content: "通过调整放电参数，可获得不同的表面粗糙度，Ra值可从0.4μm到6.3μm" },
        { title: "加工特点", content: "可加工任何导电材料，不受材料硬度限制，适合复杂形状和细微结构的加工" },
      ],
      applications: [
        "模具型腔的精加工，特别是深腔、窄槽等难加工部位",
        "模具零件上的花纹、文字加工",
        "冲模的加工",
        "微细模具的加工"
      ]
    },
    wedm: {
      title: "线切割加工(WEDM)",
      description: "线切割加工是利用金属丝作为电极，通过电火花放电对工件进行切割的加工方法，主要用于加工各种形状的冲裁模和样板。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Wire%20EDM%20machine%2C%20mold%20manufacturing%2C%20precision%20cutting&sign=e7177e948b5b9646870b49f0fa1a6bfd",
      features: [
        { title: "快走丝工艺", content: "使用钼丝作为电极，钼丝可重复使用，加工精度较低，表面粗糙度Ra一般为2.5-5μm" },
        { title: "慢走丝工艺", content: "使用铜线作为电极，铜线一次性使用，加工精度高，表面粗糙度Ra可达0.4-1.6μm" },
        { title: "精度差异", content: "慢走丝加工精度可达±0.002mm，快走丝加工精度一般为±0.01mm" },
        { title: "加工特点", content: "可加工各种复杂形状的二维轮廓，适合精密模具零件的加工" },
      ],
      applications: [
        "冲裁模的凸模、凹模加工",
        "成型模具的镶件加工",
        "精密零件的切割",
        "各种复杂形状的样板加工"
      ]
    },
    grinding: {
      title: "磨削加工",
      description: "磨削加工是利用砂轮或其他磨具对工件表面进行切削加工的方法，主要用于模具零件的精加工，提高表面精度和粗糙度。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Grinding%20machine%2C%20mold%20manufacturing%2C%20precision%20surface%20finishing&sign=651984152465b99e3c44fd9d02b91de7",
      features: [
        { title: "平面磨", content: "用于加工平面、台阶面等，可获得较高的平面度和表面粗糙度" },
        { title: "内外圆磨", content: "用于加工圆柱面、圆锥面等，适合轴类零件和孔的精加工" },
        { title: "成型磨", content: "用于加工各种成型表面，如模具的型腔、型芯等" },
        { title: "坐标磨", content: "结合了坐标镗床和磨床的特点，可进行高精度孔系加工" },
      ],
      applications: [
        "模具模板的平面加工",
        "导柱、导套等精密零件的加工",
        "模具型腔和型芯的精加工",
        "各种需要高精度表面的模具零件加工"
      ]
    },
    polishing: {
      title: "抛光工艺",
      description: "抛光是模具制造的最后一道工序，通过机械、化学或电化学的作用，降低工件表面粗糙度，提高表面光泽度和精度。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Polishing%20process%2C%20mold%20surface%20finishing%2C%20mirror%20polish&sign=1e87a1bb60a8c6330ac93638086e2722",
      features: [
        { title: "镜面抛光标准", content: "通常分为A0级(超镜面)、A1级(高镜面)、A2级(镜面)、B1级(准镜面)等几个等级" },
        { title: "抛光工具", content: "包括砂纸、油石、抛光膏、钻石研磨膏、抛光轮等" },
        { title: "抛光顺序", content: "一般按照粗磨→细磨→精磨→抛光的顺序进行，逐步提高表面精度" },
        { title: "电解抛光", content: "利用电化学作用对金属表面进行抛光，可获得极高的表面质量" },
      ],
      applications: [
        "注塑模具型腔的镜面抛光",
        "要求高表面质量的模具零件加工",
        "减少制品表面缺陷，提高脱模性能",
        "延长模具使用寿命"
      ]
    }
  };
  
  // 工艺路线规划案例
  const processRouteCase = {
    title: "塑料模具型芯加工工艺路线",
    steps: [
      { name: "材料准备", process: "选择合适的模具钢，如718H" },
      { name: "锻造", process: "改善材料组织，提高性能" },
      { name: "退火", process: "消除内应力，降低硬度，便于切削加工" },
      { name: "粗加工", process: "CNC铣削，去除大部分余量" },
      { name: "半精加工", process: "CNC铣削，预留0.5-1mm加工余量" },
      { name: "热处理", process: "淬火+回火，提高硬度和耐磨性" },
      { name: "电火花加工", process: "精加工型腔复杂部位和深槽" },
      { name: "磨削加工", process: "平面磨和外圆磨，保证尺寸精度" },
      { name: "抛光", process: "逐步提高表面粗糙度，达到要求的镜面效果" },
      { name: "检验", process: "尺寸测量、表面质量检查等" }
    ]
  };
  
  return (
    <div className="min-h-screen pt-24 pb-16 bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-200">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto mb-12 text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400">
            模具加工工艺全流程指南
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-400">
            深入了解模具制造各环节的加工工艺、特点及应用
          </p>
        </div>
        
        {/* 工艺选择区 */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-8">
          {Object.keys(processes).map((key) => (
            <motion.button
              key={key}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setActiveProcess(key)}
              className={`py-3 px-4 rounded-lg text-sm md:text-base transition-all duration-300 ${
                activeProcess === key
                  ? 'bg-blue-600 text-white font-medium shadow-md'
                  : isDark 
                    ? 'bg-gray-800 hover:bg-gray-700' 
                    : 'bg-white hover:bg-gray-100 shadow-sm'
              }`}
            >
              {processes[key as keyof typeof processes].title}
            </motion.button>
          ))}
        </div>
        
        {/* 工艺详情区 */}
        <motion.div
          key={activeProcess}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12"
        >
          {/* 左侧：工艺介绍和图片 */}
          <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} h-full`}>
            <h2 className="text-2xl font-bold mb-4">{processes[activeProcess as keyof typeof processes].title}</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-6">
              {processes[activeProcess as keyof typeof processes].description}
            </p>
            
            {/* 工艺图片 */}
            <div className="relative rounded-lg overflow-hidden mb-6">
              <img 
                src={processes[activeProcess as keyof typeof processes].image} 
                alt={processes[activeProcess as keyof typeof processes].title}
                className="w-full h-64 object-cover rounded-lg"
              />
            </div>
            
            {/* 操作按钮 */}
            <div className="flex space-x-4">
              <button className="py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all duration-300">
                <i className="fa-solid fa-play-circle mr-2"></i> 观看视频演示
              </button>
              <button className="py-2 px-4 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-all duration-300">
                <i className="fa-solid fa-book-open mr-2"></i> 详细工艺指南
              </button>
            </div>
          </div>
          
          {/* 右侧：工艺特点和应用 */}
          <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} h-full`}>
            <h3 className="text-xl font-bold mb-4">工艺特点</h3>
            
            {/* 工艺特点列表 */}
            <div className="space-y-4 mb-8">
              {processes[activeProcess as keyof typeof processes].features.map((feature, index) => (
                <div key={index} className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                  <h4 className="font-semibold mb-1">{feature.title}</h4>
                  <p className="text-gray-600 dark:text-gray-400">{feature.content}</p>
                </div>
              ))}
            </div>
            
            {/* 应用场景 */}
            <div>
              <h3 className="text-xl font-bold mb-4">应用场景</h3>
              <ul className="space-y-2">
                {processes[activeProcess as keyof typeof processes].applications.map((app, index) => (
                  <li key={index} className="flex items-start">
                    <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-3"></i>
                    <span className="text-gray-600 dark:text-gray-400">{app}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </motion.div>
        
        {/* 成本效益分析区 */}
        <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} mb-12`}>
          <h2 className="text-2xl font-bold mb-6">不同加工工艺的成本效益分析</h2>
          
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={costBenefitData}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke={isDark ? "#444" : "#ddd"} />
                <XAxis dataKey="name" stroke={isDark ? "#ccc" : "#666"} />
                <YAxis stroke={isDark ? "#ccc" : "#666"} />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: isDark ? '#333' : '#fff',
                    borderColor: isDark ? '#555' : '#ddd',
                    color: isDark ? '#fff' : '#333'
                  }}
                />
                <Legend />
                <Bar dataKey="精度" fill="#3b82f6" />
                <Bar dataKey="成本" fill="#10b981" />
                <Bar dataKey="效率" fill="#f59e0b" />
                <Bar dataKey="适用范围" fill="#8b5cf6" />
              </BarChart>
            </ResponsiveContainer>
          </div>
          
          <div className="mt-6 text-gray-600 dark:text-gray-400">
            <p>
              从图表中可以看出，不同的加工工艺在精度、成本、效率和适用范围方面各有优势。CNC加工在适用范围和效率方面表现突出，
              电火花加工和磨削加工在精度方面具有优势，而抛光工艺则在表面质量方面表现最佳。在实际生产中，
              应根据模具零件的具体要求和生产条件，选择合适的加工工艺组合。
            </p>
          </div>
        </div>
        
        {/* 工艺路线规划案例 */}
        <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
          <h2 className="text-2xl font-bold mb-6">{processRouteCase.title}</h2>
          
          <div className="relative">
            {/* 连接线 */}
            <div className="absolute left-6 top-0 bottom-0 w-0.5 bg-blue-500 dark:bg-blue-700"></div>
            
            {/* 工艺步骤 */}
            <div className="space-y-6">
              {processRouteCase.steps.map((step, index) => (
                <motion.div 
                  key={index}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  className="flex"
                >
                  <div className="relative">
                    <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center text-white font-bold z-10 relative">
                      {index + 1}
                    </div>
                  </div>
                  <div className={`ml-6 p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'} flex-1`}>
                    <h4 className="font-semibold mb-1">{step.name}</h4>
                    <p className="text-gray-600 dark:text-gray-400">{step.process}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
          
          <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-4">
            <button className="py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all duration-300">
              <i className="fa-solid fa-file-alt mr-2"></i> 下载工艺卡
            </button>
            <button className="py-3 px-4 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-all duration-300">
              <i className="fa-solid fa-tools mr-2"></i> 查看工具清单
            </button>
            <button className="py-3 px-4 bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg transition-all duration-300">
              <i className="fa-solid fa-calculator mr-2"></i> 加工时间计算
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}