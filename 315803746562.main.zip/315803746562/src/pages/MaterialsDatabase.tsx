import { useState } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/Tabs';
import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Legend, ResponsiveContainer } from 'recharts';

export default function MaterialsDatabase() {
  const { isDark } = useTheme();
  const [activeTab, setActiveTab] = useState('plastic');
  const [selectedMaterial, setSelectedMaterial] = useState('s136');
  const [selectedProcess, setSelectedProcess] = useState('hardening');
  
  // 材料性能对比数据
  const materialComparisonData = [
    { subject: '硬度', s136: 90, h718: 80, nak80: 85, skd11: 95, dc53: 96, cr12mov: 92 },
    { subject: '耐磨性', s136: 85, h718: 75, nak80: 80, skd11: 90, dc53: 92, cr12mov: 88 },
    { subject: '耐腐蚀性', s136: 95, h718: 70, nak80: 75, skd11: 65, dc53: 60, cr12mov: 55 },
    { subject: '镜面性', s136: 90, h718: 85, nak80: 95, skd11: 75, dc53: 70, cr12mov: 65 },
    { subject: '加工性', s136: 75, h718: 90, nak80: 85, skd11: 65, dc53: 60, cr12mov: 55 },
    { subject: '韧性', s136: 80, h718: 85, nak80: 82, skd11: 70, dc53: 75, cr12mov: 65 },
  ];
  
  // 塑胶模具材料数据
  const plasticMaterials = {
    s136: {
      name: "S136",
      category: "塑胶模具钢",
      description: "S136是一种高纯度的镜面抛光塑料模具钢，具有出色的耐腐蚀性和耐磨性。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=S136%20mold%20steel%2C%20metal%20material%2C%20close-up&sign=6c83f3ab348def33e4056281ac2cc73e",
      properties: [
        { name: "硬度", value: "HRC 50-52" },
        { name: "抗拉强度", value: "约1600 MPa" },
        { name: "屈服强度", value: "约1400 MPa" },
        { name: "伸长率", value: "约8%" },
        { name: "冲击韧性", value: "约35 J/cm²" },
      ],
      applications: [
        "需要高镜面度的塑料模具",
        "耐腐蚀的塑料模具",
        "高抛光要求的透明塑料零件模具",
        "PVC等腐蚀性塑料的模具"
      ],
      heatTreatment: [
        "退火：800-850°C，缓慢冷却",
        "淬火：1000-1050°C，油冷或气冷",
        "回火：200-500°C，根据要求调整硬度"
      ],
      cost: "中高"
    },
    h718: {
      name: "718H",
      category: "塑胶模具钢",
      description: "718H是一种预硬型塑料模具钢，具有良好的加工性能和抛光性能。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=718H%20mold%20steel%2C%20metal%20material%2C%20close-up&sign=9f4206c93618c7a6cfbac7d88d4f1164",
      properties: [
        { name: "硬度", value: "HRC 32-36" },
        { name: "抗拉强度", value: "约1100 MPa" },
        { name: "屈服强度", value: "约950 MPa" },
        { name: "伸长率", value: "约12%" },
        { name: "冲击韧性", value: "约50 J/cm²" },
      ],
      applications: [
        "大型塑料模具",
        "高要求的塑料模具型腔和型芯",
        "需要电火花加工的模具",
        "批量生产的塑料模具"
      ],
      heatTreatment: [
        "预硬处理：已预硬至HRC 32-36",
        "去应力退火：600-650°C，缓慢冷却",
        "不可进行淬火处理"
      ],
      cost: "中等"
    },
    nak80: {
      name: "NAK80",
      category: "塑胶模具钢",
      description: "NAK80是一种析出硬化型塑料模具钢，具有优异的镜面抛光性能和放电加工性能。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=NAK80%20mold%20steel%2C%20metal%20material%2C%20close-up&sign=135fe2032683c93efb0e15c8a5120eb9",
      properties: [
        { name: "硬度", value: "HRC 38-42" },
        { name: "抗拉强度", value: "约1300 MPa" },
        { name: "屈服强度", value: "约1150 MPa" },
        { name: "伸长率", value: "约10%" },
        { name: "冲击韧性", value: "约45 J/cm²" },
      ],
      applications: [
        "高镜面度的塑料模具",
        "精密塑料模具",
        "需要电火花加工的模具",
        "透明塑料零件模具"
      ],
      heatTreatment: [
        "时效处理：500-550°C，保温4-6小时",
        "退火：780-820°C，缓慢冷却",
        "不可进行淬火处理"
      ],
      cost: "中高"
    }
  };
  
  // 五金模具材料数据
  const metalMaterials = {
    skd11: {
      name: "SKD11",
      category: "五金模具钢",
      description: "SKD11是一种高碳高铬合金工具钢，具有高硬度、高耐磨性和良好的热处理性能。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=SKD11%20tool%20steel%2C%20metal%20material%2C%20close-up&sign=3e65e941e5b2f9f2cd996f43d7a8d70f",
      properties: [
        { name: "硬度", value: "HRC 58-62" },
        { name: "抗拉强度", value: "约2200 MPa" },
        { name: "屈服强度", value: "约1800 MPa" },
        { name: "伸长率", value: "约3%" },
        { name: "冲击韧性", value: "约20 J/cm²" },
      ],
      applications: [
        "冷冲模、冲裁模",
        "剪切刀、切边模",
        "成型模、拉深模",
        "高耐磨要求的模具零件"
      ],
      heatTreatment: [
        "退火：800-850°C，缓慢冷却",
        "淬火：1000-1050°C，油冷或气冷",
        "回火：180-250°C，低温回火"
      ],
      cost: "中等"
    },
    dc53: {
      name: "DC53",
      category: "五金模具钢",
      description: "DC53是SKD11的改良版，具有更高的韧性和耐磨性，同时保持了良好的热处理性能。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=DC53%20tool%20steel%2C%20metal%20material%2C%20close-up&sign=415651f404ee495f33551939ba39fb39",
      properties: [
        { name: "硬度", value: "HRC 60-64" },
        { name: "抗拉强度", value: "约2400 MPa" },
        { name: "屈服强度", value: "约2000 MPa" },
        { name: "伸长率", value: "约4%" },
        { name: "冲击韧性", value: "约30 J/cm²" },
      ],
      applications: [
        "精密冲裁模",
        "高速冲床模具",
        "冷挤压模、冷镦模",
        "需要高韧性和耐磨性的模具"
      ],
      heatTreatment: [
        "退火：820-850°C，缓慢冷却",
        "淬火：1030-1080°C，油冷或气冷",
        "回火：180-250°C，低温回火"
      ],
      cost: "中高"
    },
    cr12mov: {
      name: "Cr12MoV",
      category: "五金模具钢",
      description: "Cr12MoV是一种高碳高铬合金工具钢，具有高硬度、高耐磨性和良好的淬透性。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=square_hd&prompt=Cr12MoV%20tool%20steel%2C%20metal%20material%2C%20close-up&sign=548c93fac033b7cdae86b0ebceab23be",
      properties: [
        { name: "硬度", value: "HRC 58-62" },
        { name: "抗拉强度", value: "约2100 MPa" },
        { name: "屈服强度", value: "约1700 MPa" },
        { name: "伸长率", value: "约3%" },
        { name: "冲击韧性", value: "约18 J/cm²" },
      ],
      applications: [
        "冷冲模、冲裁模",
        "成型模、拉深模",
        "冷挤压模、冷镦模",
        "耐磨零件、精密夹具"
      ],
      heatTreatment: [
        "退火：830-860°C，缓慢冷却",
        "淬火：950-1000°C，油冷",
        "回火：180-250°C，低温回火"
      ],
      cost: "中等"
    }
  };
  
  // 热处理工艺数据
  const heatTreatmentProcesses = {
    hardening: {
      name: "淬火",
      description: "淬火是将钢加热到临界温度以上，保温一段时间，然后快速冷却的热处理工艺。目的是提高钢的硬度和强度。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Steel%20quenching%20process%2C%20heat%20treatment%20furnace&sign=3787a4da9e142af1ce458836b70072de",
      parameters: [
        { name: "加热温度", value: "根据钢种不同，一般在800-1200°C之间" },
        { name: "保温时间", value: "根据钢材尺寸和装炉量确定，一般为1-4小时" },
        { name: "冷却介质", value: "水、油、聚合物溶液、空气等" },
        { name: "冷却速度", value: "应足够快，以获得马氏体组织" },
      ],
      effects: [
        "提高钢的硬度和强度",
        "增加耐磨性",
        "改善切削性能(某些情况下)",
        "可能导致内应力增加和变形"
      ],
      considerations: [
        "合理选择加热温度和保温时间，避免过热和过烧",
        "选择适当的冷却介质和冷却方式，控制冷却速度",
        "注意防止变形和开裂",
        "淬火后应及时进行回火处理"
      ]
    },
    tempering: {
      name: "回火",
      description: "回火是将淬火后的钢重新加热到低于临界点的温度，保温一段时间，然后冷却的热处理工艺。目的是消除内应力，调整钢的韧性和塑性。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Steel%20tempering%20process%2C%20heat%20treatment%20furnace&sign=eaa4d9e03ac28520ad16900349e8a488",
      parameters: [
        { name: "回火温度", value: "根据要求的性能确定，一般在150-650°C之间" },
        { name: "保温时间", value: "根据钢材尺寸确定，一般为1-3小时" },
        { name: "冷却方式", value: "空冷、油冷或水冷，根据钢种和回火温度确定" },
        { name: "回火次数", value: "重要零件可进行多次回火" },
      ],
      effects: [
        "消除淬火内应力",
        "调整硬度和韧性的平衡",
        "稳定组织和尺寸",
        "提高钢的塑性和韧性"
      ],
      considerations: [
        "根据零件的使用要求选择合适的回火温度",
        "确保回火温度均匀，防止局部过热",
        "重要零件应进行多次回火",
        "回火后应缓慢冷却，避免产生新的内应力"
      ]
    },
    annealing: {
      name: "退火",
      description: "退火是将钢加热到适当温度，保温一段时间，然后缓慢冷却的热处理工艺。目的是消除内应力，软化钢材，改善切削加工性能。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Steel%20annealing%20process%2C%20heat%20treatment%20furnace&sign=67ce5e086695879e2133bcf65e325ffe",
      parameters: [
        { name: "退火温度", value: "根据钢种不同，一般在Ac1或Ac3以上20-50°C" },
        { name: "保温时间", value: "根据钢材尺寸和装炉量确定，一般为2-6小时" },
        { name: "冷却速度", value: "缓慢冷却，通常随炉冷却" },
        { name: "冷却终点", value: "一般冷却至500°C以下，然后出炉空冷" },
      ],
      effects: [
        "消除内应力",
        "降低硬度，改善切削加工性能",
        "均匀组织，改善钢材性能",
        "消除铸件和锻件的组织缺陷"
      ],
      considerations: [
        "合理选择退火温度和保温时间",
        "控制冷却速度，确保退火质量",
        "对于大型零件，应考虑退火后的变形问题",
        "退火炉应具有良好的温度均匀性"
      ]
    },
    nitriding: {
      name: "氮化",
      description: "氮化是将钢置于含氮介质中，加热到一定温度，使氮原子渗入钢表面的化学热处理工艺。目的是提高钢的表面硬度、耐磨性和耐腐蚀性。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=Steel%20nitriding%20process%2C%20heat%20treatment%20furnace&sign=6c25fef90920c3fa95bd9f4aa32e520c",
      parameters: [
        { name: "氮化温度", value: "一般在500-600°C之间" },
        { name: "氮化时间", value: "根据要求的渗层深度确定，一般为10-100小时" },
        { name: "氮化介质", value: "液氨、尿素、氨气等" },
        { name: "渗层深度", value: "一般为0.1-0.6mm" },
      ],
      effects: [
        "显著提高表面硬度(可达HV 900-1200)",
        "提高耐磨性和抗疲劳性能",
        "改善耐腐蚀性",
        "处理温度低，变形小"
      ],
      considerations: [
        "氮化前应进行调质处理，获得均匀的回火索氏体组织",
        "氮化零件应进行去应力退火，防止变形和开裂",
        "选择适合氮化的钢材(如含Cr、Mo、Al等元素的钢)",
        "注意控制氮化层的脆性"
      ]
    }
  };
  
  // 材料选择决策树数据
  const materialSelectionTree = {
    title: "模具材料选择决策树",
    steps: [
      {
        question: "模具类型是什么？",
        options: [
          {
            answer: "塑胶模具",
            next: 1
          },
          {
            answer: "五金模具",
            next: 2
          }
        ]
      },
      {
        question: "塑胶模具的主要要求是什么？",
        options: [
          {
            answer: "高镜面度",
            recommendation: "推荐材料：S136、NAK80",
            next: null
          },
          {
            answer: "耐腐蚀性",
            recommendation: "推荐材料：S136、2083",
            next: null
          },
          {
            answer: "大型模具",
            recommendation: "推荐材料：718H、P20",
            next: null
          },
          {
            answer: "精密小型模具",
            recommendation: "推荐材料：NAK80、S136",
            next: null
          }
        ]
      },
      {
        question: "五金模具的主要要求是什么？",
        options: [
          {
            answer: "高硬度高耐磨",
            recommendation: "推荐材料：SKD11、DC53",
            next: null
          },
          {
            answer: "高韧性",
            recommendation: "推荐材料：DC53、ASP60",
            next: null
          },
          {
            answer: "大型冲压模",
            recommendation: "推荐材料：Cr12MoV、D2",
            next: null
          },
          {
            answer: "精密冲裁模",
            recommendation: "推荐材料：DC53、SKH-9",
            next: null
          }
        ]
      }
    ]
  };
  
  const [currentStep, setCurrentStep] = useState(0);
  const [recommendation, setRecommendation] = useState("");
  
  const handleOptionClick = (option: any) => {
    if (option.recommendation) {
      setRecommendation(option.recommendation);
    }
    if (option.next !== null) {
      setCurrentStep(option.next);
    }
  };
  
  const resetDecisionTree = () => {
    setCurrentStep(0);
    setRecommendation("");
  };
  
  return (
    <div className="min-h-screen pt-24 pb-16 bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-200">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto mb-12 text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400">
            模具材料与热处理数据库
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-400">
            探索各种模具材料的性能特点、适用场景及热处理工艺
          </p>
        </div>
        
        {/* 主要内容区域 */}
        <Tabs defaultValue="plastic" className="w-full" onValueChange={setActiveTab}>
          <div className="flex justify-center mb-8">
            <TabsList className={`p-1 rounded-xl ${isDark ? 'bg-gray-800' : 'bg-gray-100'}`}>
              <TabsTrigger 
                value="plastic" 
                className={`px-6 py-2 rounded-lg transition-all duration-300 ${
                  activeTab === 'plastic' 
                    ? 'bg-blue-600 text-white font-medium' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                塑胶模具材料
              </TabsTrigger>
              <TabsTrigger 
                value="metal" 
                className={`px-6 py-2 rounded-lg transition-all duration-300 ${
                  activeTab === 'metal' 
                    ? 'bg-blue-600 text-white font-medium' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                五金模具材料
              </TabsTrigger>
              <TabsTrigger 
                value="heat" 
                className={`px-6 py-2 rounded-lg transition-all duration-300 ${
                  activeTab === 'heat' 
                    ? 'bg-blue-600 text-white font-medium' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                热处理工艺
              </TabsTrigger>
              <TabsTrigger 
                value="selection" 
                className={`px-6 py-2 rounded-lg transition-all duration-300 ${
                  activeTab === 'selection' 
                    ? 'bg-blue-600 text-white font-medium' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                材料选择工具
              </TabsTrigger>
            </TabsList>
          </div>
          
          {/* 塑胶模具材料内容 */}
          <TabsContent value="plastic" className="mt-0">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              {/* 材料选择器 */}
              <div className="flex flex-wrap gap-3 mb-8 justify-center">
                {Object.keys(plasticMaterials).map((key) => (
                  <motion.button
                    key={key}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setSelectedMaterial(key)}
                    className={`py-2 px-4 rounded-lg text-sm md:text-base transition-all duration-300 ${
                      selectedMaterial === key
                        ? 'bg-blue-600 text-white font-medium shadow-md'
                        : isDark 
                          ? 'bg-gray-800 hover:bg-gray-700' 
                          : 'bg-white hover:bg-gray-100 shadow-sm'
                    }`}
                  >
                    {plasticMaterials[key as keyof typeof plasticMaterials].name}
                  </motion.button>
                ))}
              </div>
              
              {/* 材料详情和性能对比 */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
                {/* 材料详情 */}
                <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} h-full`}>
                  <h2 className="text-2xl font-bold mb-4">{plasticMaterials[selectedMaterial as keyof typeof plasticMaterials].name}</h2>
                  <p className="text-lg font-medium text-blue-600 dark:text-blue-400 mb-4">
                    {plasticMaterials[selectedMaterial as keyof typeof plasticMaterials].category}
                  </p>
                  
                  {/* 材料图片 */}
                  <div className="relative rounded-lg overflow-hidden mb-6">
                    <img 
                      src={plasticMaterials[selectedMaterial as keyof typeof plasticMaterials].image} 
                      alt={plasticMaterials[selectedMaterial as keyof typeof plasticMaterials].name}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                  </div>
                  
                  <p className="text-gray-600 dark:text-gray-400 mb-6">
                    {plasticMaterials[selectedMaterial as keyof typeof plasticMaterials].description}
                  </p>
                  
                  {/* 性能参数 */}
                  <div className="mb-6">
                    <h3 className="text-xl font-bold mb-3">性能参数</h3>
                    <div className="grid grid-cols-2 gap-3">
                      {plasticMaterials[selectedMaterial as keyof typeof plasticMaterials].properties.map((prop, index) => (
                        <div key={index} className={`p-3 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{prop.name}</p>
                          <p className="font-medium">{prop.value}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* 成本信息 */}
                  <div className={`p-3 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'} inline-block mb-6`}>
                    <p className="text-sm text-gray-500 dark:text-gray-400">成本水平</p>
                    <p className="font-medium">{plasticMaterials[selectedMaterial as keyof typeof plasticMaterials].cost}</p>
                  </div>
                </div>
                
                {/* 应用场景和热处理 */}
                <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} h-full`}>
                  {/* 应用场景 */}
                  <div className="mb-8">
                    <h3 className="text-xl font-bold mb-4">应用场景</h3>
                    <ul className="space-y-2">
                      {plasticMaterials[selectedMaterial as keyof typeof plasticMaterials].applications.map((app, index) => (
                        <li key={index} className="flex items-start">
                          <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-3"></i>
                          <span className="text-gray-600 dark:text-gray-400">{app}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  {/* 热处理工艺 */}
                  <div>
                    <h3 className="text-xl font-bold mb-4">热处理工艺</h3>
                    <ul className="space-y-2">
                      {plasticMaterials[selectedMaterial as keyof typeof plasticMaterials].heatTreatment.map((process, index) => (
                        <li key={index} className="flex items-start">
                          <i className="fa-solid fa-fire text-orange-500 mt-1 mr-3"></i>
                          <span className="text-gray-600 dark:text-gray-400">{process}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
              
              {/* 材料性能对比雷达图 */}
              <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} mb-8`}>
                <h2 className="text-2xl font-bold mb-6">塑胶模具材料性能对比</h2>
                <div className="h-80 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart outerRadius={90} data={materialComparisonData}>
                      <PolarGrid stroke={isDark ? "#444" : "#ddd"} />
                      <PolarAngleAxis dataKey="subject" stroke={isDark ? "#ccc" : "#666"} />
                      <PolarRadiusAxis angle={30} domain={[0, 100]} stroke={isDark ? "#ccc" : "#666"} />
                      <Radar name="S136" dataKey="s136" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.5} />
                      <Radar name="718H" dataKey="h718" stroke="#10b981" fill="#10b981" fillOpacity={0.5} />
                      <Radar name="NAK80" dataKey="nak80" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.5} />
                      <Legend />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </motion.div>
          </TabsContent>
          
          {/* 五金模具材料内容 */}
          <TabsContent value="metal" className="mt-0">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              {/* 材料选择器 */}
              <div className="flex flex-wrap gap-3 mb-8 justify-center">
                {Object.keys(metalMaterials).map((key) => (
                  <motion.button
                    key={key}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setSelectedMaterial(key)}
                    className={`py-2 px-4 rounded-lg text-sm md:text-base transition-all duration-300 ${
                      selectedMaterial === key
                        ? 'bg-blue-600 text-white font-medium shadow-md'
                        : isDark 
                          ? 'bg-gray-800 hover:bg-gray-700' 
                          : 'bg-white hover:bg-gray-100 shadow-sm'
                    }`}
                  >
                    {metalMaterials[key as keyof typeof metalMaterials].name}
                  </motion.button>
                ))}
              </div>
              
              {/* 材料详情和性能对比 */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
                {/* 材料详情 */}
                <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} h-full`}>
                  <h2 className="text-2xl font-bold mb-4">{metalMaterials[selectedMaterial as keyof typeof metalMaterials].name}</h2>
                  <p className="text-lg font-medium text-blue-600 dark:text-blue-400 mb-4">
                    {metalMaterials[selectedMaterial as keyof typeof metalMaterials].category}
                  </p>
                  
                  {/* 材料图片 */}
                  <div className="relative rounded-lg overflow-hidden mb-6">
                    <img 
                      src={metalMaterials[selectedMaterial as keyof typeof metalMaterials].image} 
                      alt={metalMaterials[selectedMaterial as keyof typeof metalMaterials].name}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                  </div>
                  
                  <p className="text-gray-600 dark:text-gray-400 mb-6">
                    {metalMaterials[selectedMaterial as keyof typeof metalMaterials].description}
                  </p>
                  
                  {/* 性能参数 */}
                  <div className="mb-6">
                    <h3 className="text-xl font-bold mb-3">性能参数</h3>
                    <div className="grid grid-cols-2 gap-3">
                      {metalMaterials[selectedMaterial as keyof typeof metalMaterials].properties.map((prop, index) => (
                        <div key={index} className={`p-3 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                          <p className="text-sm text-gray-500 dark:text-gray-400">{prop.name}</p>
                          <p className="font-medium">{prop.value}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* 成本信息 */}
                  <div className={`p-3 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'} inline-block mb-6`}>
                    <p className="text-sm text-gray-500 dark:text-gray-400">成本水平</p>
                    <p className="font-medium">{metalMaterials[selectedMaterial as keyof typeof metalMaterials].cost}</p>
                  </div>
                </div>
                
                {/* 应用场景和热处理 */}
                <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} h-full`}>
                  {/* 应用场景 */}
                  <div className="mb-8">
                    <h3 className="text-xl font-bold mb-4">应用场景</h3>
                    <ul className="space-y-2">
                      {metalMaterials[selectedMaterial as keyof typeof metalMaterials].applications.map((app, index) => (
                        <li key={index} className="flex items-start">
                          <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-3"></i>
                          <span className="text-gray-600 dark:text-gray-400">{app}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  {/* 热处理工艺 */}
                  <div>
                    <h3 className="text-xl font-bold mb-4">热处理工艺</h3>
                    <ul className="space-y-2">
                      {metalMaterials[selectedMaterial as keyof typeof metalMaterials].heatTreatment.map((process, index) => (
                        <li key={index} className="flex items-start">
                          <i className="fa-solid fa-fire text-orange-500 mt-1 mr-3"></i>
                          <span className="text-gray-600 dark:text-gray-400">{process}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
              
              {/* 材料性能对比雷达图 */}
              <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
                <h2 className="text-2xl font-bold mb-6">五金模具材料性能对比</h2>
                <div className="h-80 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <RadarChart outerRadius={90} data={materialComparisonData}>
                      <PolarGrid stroke={isDark ? "#444" : "#ddd"} />
                      <PolarAngleAxis dataKey="subject" stroke={isDark ? "#ccc" : "#666"} />
                      <PolarRadiusAxis angle={30} domain={[0, 100]} stroke={isDark ? "#ccc" : "#666"} />
                      <Radar name="SKD11" dataKey="skd11" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.5} />
                      <Radar name="DC53" dataKey="dc53" stroke="#10b981" fill="#10b981" fillOpacity={0.5} />
                      <Radar name="Cr12MoV" dataKey="cr12mov" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.5} />
                      <Legend />
                    </RadarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </motion.div>
          </TabsContent>
          
          {/* 热处理工艺内容 */}
          <TabsContent value="heat" className="mt-0">
            <motion.div initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              {/* 工艺选择器 */}
              <div className="flex flex-wrap gap-3 mb-8 justify-center">
                {Object.keys(heatTreatmentProcesses).map((key) => (
                  <motion.button
                    key={key}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setSelectedProcess(key)}
                    className={`py-2 px-4 rounded-lg text-sm md:text-base transition-all duration-300 ${
                      selectedProcess === key
                        ? 'bg-blue-600 text-white font-medium shadow-md'
                        : isDark 
                          ? 'bg-gray-800 hover:bg-gray-700' 
                          : 'bg-white hover:bg-gray-100 shadow-sm'
                    }`}
                  >
                    {heatTreatmentProcesses[key as keyof typeof heatTreatmentProcesses].name}
                  </motion.button>
                ))}
              </div>
              
              {/* 工艺详情 */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
                {/* 工艺介绍和图片 */}
                <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} h-full`}>
                  <h2 className="text-2xl font-bold mb-4">{heatTreatmentProcesses[selectedProcess as keyof typeof heatTreatmentProcesses].name}</h2>
                  
                  {/* 工艺图片 */}
                  <div className="relative rounded-lg overflow-hidden mb-6">
                    <img 
                      src={heatTreatmentProcesses[selectedProcess as keyof typeof heatTreatmentProcesses].image} 
                      alt={heatTreatmentProcesses[selectedProcess as keyof typeof heatTreatmentProcesses].name}
                      className="w-full h-64 object-cover rounded-lg"
                    />
                  </div>
                  
                  <p className="text-gray-600 dark:text-gray-400 mb-6">
                    {heatTreatmentProcesses[selectedProcess as keyof typeof heatTreatmentProcesses].description}
                  </p>
                  
                  {/* 操作按钮 */}
                  <div className="flex space-x-4">
                    <button className="py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all duration-300">
                      <i className="fa-solid fa-play-circle mr-2"></i> 观看视频演示
                    </button>
                    <button className="py-2 px-4 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-all duration-300">
                      <i className="fa-solid fa-file-alt mr-2"></i> 下载工艺参数表
                    </button>
                  </div>
                </div>
                
                {/* 工艺参数和效果 */}
                <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} h-full`}>
                  {/* 工艺参数 */}
                  <div className="mb-8">
                    <h3 className="text-xl font-bold mb-4">工艺参数</h3>
                    <div className="space-y-3">
                      {heatTreatmentProcesses[selectedProcess as keyof typeof heatTreatmentProcesses].parameters.map((param, index) => (
                        <div key={index} className={`p-3 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                          <p className="font-medium">{param.name}</p>
                          <p className="text-gray-600 dark:text-gray-400">{param.value}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  {/* 工艺效果 */}
                  <div className="mb-8">
                    <h3 className="text-xl font-bold mb-4">工艺效果</h3>
                    <ul className="space-y-2">
                      {heatTreatmentProcesses[selectedProcess as keyof typeof heatTreatmentProcesses].effects.map((effect, index) => (
                        <li key={index} className="flex items-start">
                          <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-3"></i>
                          <span className="text-gray-600 dark:text-gray-400">{effect}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  {/* 注意事项 */}
                  <div>
                    <h3 className="text-xl font-bold mb-4">注意事项</h3>
                    <ul className="space-y-2">
                      {heatTreatmentProcesses[selectedProcess as keyof typeof heatTreatmentProcesses].considerations.map((consideration, index) => (
                        <li key={index} className="flex items-start">
                          <i className="fa-solid fa-exclamation-circle text-amber-500 mt-1 mr-3"></i>
                          <span className="text-gray-600 dark:text-gray-400">{consideration}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
              
              {/* 热处理曲线和硬度测试标准 */}
              <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
                <h2 className="text-2xl font-bold mb-6">热处理曲线及硬度测试标准</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <h3 className="text-xl font-bold mb-4">典型热处理曲线</h3>
                    <div className="bg-gray-100 dark:bg-gray-700 rounded-lg p-4 h-64 flex items-center justify-center">
                      <div className="text-center">
                        <i className="fa-solid fa-chart-line text-4xl text-blue-600 mb-3"></i>
                        <p className="text-gray-600 dark:text-gray-400">热处理温度-时间曲线图</p>
                        <button className="mt-3 py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all duration-300">
                          查看详细曲线
                        </button>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-4">硬度测试标准</h3>
                    <div className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                      <ul className="space-y-3">
                        <li className="flex justify-between">
                          <span>布氏硬度(HB)</span>
                          <span className="text-gray-600 dark:text-gray-400">使用钢球压头，测量压痕直径</span>
                        </li>
                        <li className="flex justify-between">
                          <span>洛氏硬度(HRC)</span>
                          <span className="text-gray-600 dark:text-gray-400">使用金刚石压头，测量压痕深度</span>
                        </li>
                        <li className="flex justify-between">
                          <span>维氏硬度(HV)</span>
                          <span className="text-gray-600 dark:text-gray-400">使用金刚石棱锥压头，测量压痕对角线</span>
                        </li>
                        <li className="flex justify-between">
                          <span>肖氏硬度(HS)</span>
                          <span className="text-gray-600 dark:text-gray-400">使用冲击体，测量回弹高度</span>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </TabsContent>
          
          {/* 材料选择工具内容 */}
          <TabsContent value="selection" className="mt-0">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              {/* 材料选择决策树 */}
              <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} mb-8`}>
                <h2 className="text-2xl font-bold mb-6">{materialSelectionTree.title}</h2>
                
                <div className="relative">
                  {/* 决策树内容 */}
                  {!recommendation ? (
                    <div>
                      <div className={`p-5 rounded-xl mb-8 ${isDark ? 'bg-gray-700' : 'bg-blue-50'} border-l-4 border-blue-600`}>
                        <h3 className="text-xl font-bold mb-2">{materialSelectionTree.steps[currentStep].question}</h3>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {materialSelectionTree.steps[currentStep].options.map((option, index) => (
                          <motion.button
                            key={index}
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => handleOptionClick(option)}
                            className={`p-4 rounded-lg text-left transition-all duration-300 ${
                              isDark 
                                ? 'bg-gray-700 hover:bg-gray-600' 
                                : 'bg-white hover:bg-gray-50 shadow-sm border border-gray-200 dark:border-gray-700'
                            }`}
                          >
                            {option.answer}
                          </motion.button>
                        ))}
                      </div>
                      
                      {currentStep > 0 && (
                        <div className="mt-6 text-center">
                          <button
                            onClick={() => setCurrentStep(prev => Math.max(0, prev - 1))}
                            className={`inline-flex items-center px-4 py-2 rounded-lg transition-all duration-300 ${
                              isDark 
                                ? 'bg-gray-700 hover:bg-gray-600' 
                                : 'bg-gray-200 hover:bg-gray-300'
                            }`}
                          >
                            <i className="fa-solid fa-arrow-left mr-2"></i> 上一步
                          </button>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="text-center">
                      <div className="w-20 h-20 bg-green-500 rounded-full flex items-center justify-center text-white text-2xl font-bold mx-auto mb-6">
                        <i className="fa-solid fa-check"></i>
                      </div>
                      <h3 className="text-2xl font-bold mb-4">推荐材料</h3>
                      <p className="text-xl text-gray-600 dark:text-gray-400 mb-8">{recommendation}</p>
                      <button
                        onClick={resetDecisionTree}
                        className="py-3 px-6 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all duration-300"
                      >
                        重新选择
                      </button>
                    </div>
                  )}
                </div>
              </div>
              
              {/* 材料选择计算器 */}
              <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
                <h2 className="text-2xl font-bold mb-6">材料选择计算器</h2>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                  {/* 产品要求输入 */}
                  <div>
                    <h3 className="text-xl font-bold mb-4">产品要求</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">产品类型</label>
                        <select className={`w-full p-2 rounded-lg border ${
                          isDark 
                            ? 'bg-gray-700 border-gray-600' 
                            : 'bg-white border-gray-300'
                        }`}>
                          <option>塑胶产品</option>
                          <option>五金产品</option>
                          <option>复合材料产品</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">预计产量</label>
                        <select className={`w-full p-2 rounded-lg border ${
                          isDark 
                            ? 'bg-gray-700 border-gray-600' 
                            : 'bg-white border-gray-300'
                        }`}>
                          <option>小批量(&lt;10,000件)</option>
                          <option>中批量(10,000-100,000件)</option>
                          <option>大批量(&gt;100,000件)</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">表面要求</label>
                        <select className={`w-full p-2 rounded-lg border ${
                          isDark 
                            ? 'bg-gray-700 border-gray-600' 
                            : 'bg-white border-gray-300'
                        }`}>
                          <option>普通表面</option>
                          <option>一般抛光</option>
                          <option>镜面抛光</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">特殊要求</label>
                        <select className={`w-full p-2 rounded-lg border ${
                          isDark 
                            ? 'bg-gray-700 border-gray-600' 
                            : 'bg-white border-gray-300'
                        }`}>
                          <option>无特殊要求</option>
                          <option>耐腐蚀</option>
                          <option>高耐磨</option>
                          <option>高韧性</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  
                  {/* 成本预算输入 */}
                  <div>
                    <h3 className="text-xl font-bold mb-4">成本预算</h3>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium mb-1">模具总成本预算</label>
                        <select className={`w-full p-2 rounded-lg border ${
                          isDark 
                            ? 'bg-gray-700 border-gray-600' 
                            : 'bg-white border-gray-300'
                        }`}>
                          <option>低成本(&lt;5万元)</option>
                          <option>中等成本(5-15万元)</option>
                          <option>高成本(&gt;15万元)</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">材料成本占比</label>
                        <input 
                          type="range" 
                          min="10" 
                          max="50" 
                          defaultValue="30"
                          className="w-full h-2 bg-gray-300 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                        />
                        <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400 mt-1">
                          <span>10%</span>
                          <span>30%</span>
                          <span>50%</span>
                        </div>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">交货周期</label>
                        <select className={`w-full p-2 rounded-lg border ${
                          isDark 
                            ? 'bg-gray-700 border-gray-600' 
                            : 'bg-white border-gray-300'
                        }`}>
                          <option>紧急(&lt;2周)</option>
                          <option>标准(2-4周)</option>
                          <option>宽松(&gt;4周)</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium mb-1">使用寿命要求</label>
                        <select className={`w-full p-2 rounded-lg border ${
                          isDark 
                            ? 'bg-gray-700 border-gray-600' 
                            : 'bg-white border-gray-300'
                        }`}>
                          <option>一次性或低寿命</option>
                          <option>中等寿命</option>
                          <option>高寿命</option>
                        </select>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* 计算按钮和结果 */}
                <div className="text-center">
                  <button className="py-3 px-8 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all duration-300 mb-6">
                    计算最佳材料方案
                  </button>
                  
                  <div className={`p-5 rounded-xl inline-block ${isDark ? 'bg-gray-700' : 'bg-green-50'} border-l-4 border-green-600 max-w-lg`}>
                    <h3 className="text-xl font-bold mb-2">推荐材料方案</h3>
                    <p className="text-gray-600 dark:text-gray-400 mb-4">
                      基于您的输入，我们推荐使用 <span className="font-bold text-green-600 dark:text-green-400">S136</span> 材料，
                      配合 <span className="font-bold text-green-600 dark:text-green-400">淬火+回火+氮化</span> 热处理工艺。
                    </p>
                    <p className="text-gray-600 dark:text-gray-400">
                      该方案能够满足您的产品要求，预计使用寿命可达 50 万模次以上，材料成本约占模具总成本的 25%。
                    </p>
                  </div>
                </div>
              </div>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}