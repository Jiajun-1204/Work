import { useState } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/Tabs';
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts';

export default function KnowledgeQuiz() {
  const { isDark } = useTheme();
  const [activeCategory, setActiveCategory] = useState('basics');
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<{[key: number]: string}>({});
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [score, setScore] = useState(0);
  
  // 题库数据
  const quizQuestions = {
    basics: {
      category: "模具基础",
      description: "测试您对模具基础知识的掌握程度，包括模具类型、基本结构和工作原理等。",
      questions: [
        {
          id: 1,
          question: "注塑模具中，以下哪个部件直接形成制品的形状？",
          options: [
            { id: "A", text: "模架", isCorrect: false },
            { id: "B", text: "型腔", isCorrect: true },
            { id: "C", text: "顶针", isCorrect: false },
            { id: "D", text: "冷却水道", isCorrect: false }
          ]
        },
        {
          id: 2,
          question: "以下哪种模具类型适用于生产塑料零件？",
          options: [
            { id: "A", text: "注塑模", isCorrect: true },
            { id: "B", text: "冲裁模", isCorrect: false },
            { id: "C", text: "锻造模", isCorrect: false },
            { id: "D", text: "压铸模", isCorrect: false }
          ]
        },
        {
          id: 3,
          question: "模具中导柱和导套的主要作用是什么？",
          options: [
            { id: "A", text: "冷却模具", isCorrect: false },
            { id: "B", text: "顶出制品", isCorrect: false },
            { id: "C", text: "导向和定位", isCorrect: true },
            { id: "D", text: "形成流道", isCorrect: false }
          ]
        },
        {
          id: 4,
          question: "以下哪个不是注塑成型的主要阶段？",
          options: [
            { id: "A", text: "合模", isCorrect: false },
            { id: "B", text: "注射", isCorrect: false },
            { id: "C", text: "锻造", isCorrect: true },
            { id: "D", text: "冷却", isCorrect: false }
          ]
        },
        {
          id: 5,
          question: "模具设计中，脱模斜度的主要作用是什么？",
          options: [
            { id: "A", text: "便于制品脱模", isCorrect: true },
            { id: "B", text: "增加模具强度", isCorrect: false },
            { id: "C", text: "改善冷却效果", isCorrect: false },
            { id: "D", text: "减少材料消耗", isCorrect: false }
          ]
        }
      ]
    },
    materials: {
      category: "材料与热处理",
      description: "测试您对模具材料特性、热处理工艺和选择原则的了解程度。",
      questions: [
        {
          id: 1,
          question: "以下哪种材料通常用于制造高镜面度的塑料模具？",
          options: [
            { id: "A", text: "S136", isCorrect: true },
            { id: "B", text: "SKD11", isCorrect: false },
            { id: "C", text: "P20", isCorrect: false },
            { id: "D", text: "Cr12MoV", isCorrect: false }
          ]
        },
        {
          id: 2,
          question: "淬火的主要目的是什么？",
          options: [
            { id: "A", text: "降低硬度", isCorrect: false },
            { id: "B", text: "提高硬度和强度", isCorrect: true },
            { id: "C", text: "消除内应力", isCorrect: false },
            { id: "D", text: "改善切削性能", isCorrect: false }
          ]
        },
        {
          id: 3,
          question: "以下哪种材料属于预硬型塑料模具钢？",
          options: [
            { id: "A", text: "718H", isCorrect: true },
            { id: "B", text: "S136", isCorrect: false },
            { id: "C", text: "SKD11", isCorrect: false },
            { id: "D", text: "DC53", isCorrect: false }
          ]
        },
        {
          id: 4,
          question: "氮化处理可以提高钢材的哪些性能？",
          options: [
            { id: "A", text: "表面硬度和耐磨性", isCorrect: true },
            { id: "B", text: "韧性", isCorrect: false },
            { id: "C", text: "塑性", isCorrect: false },
            { id: "D", text: "导电性", isCorrect: false }
          ]
        },
        {
          id: 5,
          question: "以下哪种材料常用于制造五金冲压模具？",
          options: [
            { id: "A", text: "SKD11", isCorrect: true },
            { id: "B", text: "NAK80", isCorrect: false },
            { id: "C", text: "718H", isCorrect: false },
            { id: "D", text: "P20", isCorrect: false }
          ]
        }
      ]
    },
    processing: {
      category: "加工工艺",
      description: "测试您对模具加工工艺、设备和操作要点的熟悉程度。",
      questions: [
        {
          id: 1,
          question: "CNC加工中，球头刀主要用于加工什么形状的表面？",
          options: [
            { id: "A", text: "平面", isCorrect: false },
            { id: "B", text: "曲面", isCorrect: true },
            { id: "C", text: "孔", isCorrect: false },
            { id: "D", text: "槽", isCorrect: false }
          ]
        },
        {
          id: 2,
          question: "电火花加工（EDM）的原理是什么？",
          options: [
            { id: "A", text: "机械切削", isCorrect: false },
            { id: "B", text: "激光切割", isCorrect: false },
            { id: "C", text: "电火花腐蚀", isCorrect: true },
            { id: "D", text: "化学腐蚀", isCorrect: false }
          ]
        },
        {
          id: 3,
          question: "慢走丝线切割与快走丝线切割相比，以下哪个说法正确？",
          options: [
            { id: "A", text: "加工精度更高", isCorrect: true },
            { id: "B", text: "加工速度更快", isCorrect: false },
            { id: "C", text: "电极丝可重复使用", isCorrect: false },
            { id: "D", text: "成本更低", isCorrect: false }
          ]
        },
        {
          id: 4,
          question: "以下哪种加工方法主要用于模具零件的精加工和表面光整？",
          options: [
            { id: "A", text: "抛光", isCorrect: true },
            { id: "B", text: "粗铣", isCorrect: false },
            { id: "C", text: "钻孔", isCorrect: false },
            { id: "D", text: "锯切", isCorrect: false }
          ]
        },
        {
          id: 5,
          question: "模具加工中，磨削加工主要用于保证零件的什么精度？",
          options: [
            { id: "A", text: "尺寸精度", isCorrect: false },
            { id: "B", text: "形状精度", isCorrect: false },
            { id: "C", text: "位置精度", isCorrect: false },
            { id: "D", text: "以上都是", isCorrect: true }
          ]
        }
      ]
    },
    design: {
      category: "模具设计",
      description: "测试您对模具设计原则、流程和常见问题解决方案的掌握程度。",
      questions: [
        {
          id: 1,
          question: "模具设计中，浇口位置的选择应考虑什么因素？",
          options: [
            { id: "A", text: "流动路径最短", isCorrect: false },
            { id: "B", text: "避免熔接线", isCorrect: false },
            { id: "C", text: "填充平衡", isCorrect: false },
            { id: "D", text: "以上都是", isCorrect: true }
          ]
        },
        {
          id: 2,
          question: "以下哪种冷却系统设计可以提高冷却效率？",
          options: [
            { id: "A", text: "单一冷却水道", isCorrect: false },
            { id: "B", text: "串联冷却水道", isCorrect: false },
            { id: "C", text: "并联冷却水道", isCorrect: true },
            { id: "D", text: "无特定设计", isCorrect: false }
          ]
        },
        {
          id: 3,
          question: "模具设计中，分型面的选择应遵循什么原则？",
          options: [
            { id: "A", text: "利于制品脱模", isCorrect: false },
            { id: "B", text: "简化模具结构", isCorrect: false },
            { id: "C", text: "保证制品外观质量", isCorrect: false },
            { id: "D", text: "以上都是", isCorrect: true }
          ]
        },{
          id: 4,
          question: "对于有倒扣的塑料制品，通常采用什么机构进行脱模？",
          options: [
            { id: "A", text: "顶针", isCorrect: false },
            { id: "B", text: "司筒", isCorrect: false },
            { id: "C", text: "斜顶或行位", isCorrect: true },
            { id: "D", text: "推板", isCorrect: false }
          ]
        },
        {
          id: 5,
          question: "模具设计的第一步通常是什么？",
          options: [
            { id: "A", text: "确定模架", isCorrect: false },
            { id: "B", text: "分析制品", isCorrect: true },
            { id: "C", text: "设计型腔", isCorrect: false },
            { id: "D", text: "选择材料", isCorrect: false }
          ]
        }
      ]
    }
  };
  
  // 模拟测试历史数据
  const testHistory = [
    { category: "模具基础", score: 85, date: "2023-10-15" },
    { category: "材料与热处理", score: 75, date: "2023-10-10" },
    { category: "加工工艺", score: 90, date: "2023-10-05" },
    { category: "模具设计", score: 80, date: "2023-09-28" }
  ];
  
  // 饼图数据
  const pieData = [
    { name: '正确', value: score },
    { name: '错误', value: quizQuestions[activeCategory as keyof typeof quizQuestions].questions.length - score }
  ];
  
  const COLORS = ['#10b981', '#ef4444'];
  
  // 重置测试
  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswers({});
    setQuizCompleted(false);
    setScore(0);
  };
  
  // 选择答案
  const handleAnswerSelect = (answerId: string) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [currentQuestion]: answerId
    }));
  };
  
  // 下一题
  const handleNextQuestion = () => {
    if (currentQuestion < quizQuestions[activeCategory as keyof typeof quizQuestions].questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      // 计算得分
      let newScore = 0;
      quizQuestions[activeCategory as keyof typeof quizQuestions].questions.forEach((q, index) => {
        const selectedOption = q.options.find(opt => opt.id === selectedAnswers[index]);
        if (selectedOption && selectedOption.isCorrect) {
          newScore++;
        }
      });
      setScore(newScore);
      setQuizCompleted(true);
    }
  };
  
  // 上一题
  const handlePrevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };
  
  return (
    <div className="min-h-screen pt-24 pb-16 bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-200">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto mb-12 text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400">
            知识测验
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-400">
            通过测验检验您对模具工程知识的掌握程度，巩固学习效果
          </p>
        </div>
        
        {/* 主要内容区域 */}
        <Tabs defaultValue="basics" className="w-full" onValueChange={(value) => {
          setActiveCategory(value);
          resetQuiz();
        }}>
          <div className="flex justify-center mb-8">
            <TabsList className={`p-1 rounded-xl ${isDark ? 'bg-gray-800' : 'bg-gray-100'}`}>
              <TabsTrigger 
                value="basics" 
                className={`px-6 py-2 rounded-lg transition-all duration-300 ${
                  activeCategory === 'basics' 
                    ? 'bg-blue-600 text-white font-medium' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                模具基础
              </TabsTrigger>
              <TabsTrigger 
                value="materials" 
                className={`px-6 py-2 rounded-lg transition-all duration-300 ${
                  activeCategory === 'materials' 
                    ? 'bg-blue-600 text-white font-medium' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                材料与热处理
              </TabsTrigger>
              <TabsTrigger 
                value="processing" 
                className={`px-6 py-2 rounded-lg transition-all duration-300 ${
                  activeCategory === 'processing' 
                    ? 'bg-blue-600 text-white font-medium' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                加工工艺
              </TabsTrigger>
              <TabsTrigger 
                value="design" 
                className={`px-6 py-2 rounded-lg transition-all duration-300 ${
                  activeCategory === 'design' 
                    ? 'bg-blue-600 text-white font-medium' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                模具设计
              </TabsTrigger>
            </TabsList>
          </div>
          
          {/* 各分类内容 */}
          {Object.keys(quizQuestions).map((key) => (
            <TabsContent key={key} value={key} className="mt-0">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                {/* 测验说明 */}
                <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} mb-8`}>
                  <h2 className="text-2xl font-bold mb-2">{quizQuestions[key as keyof typeof quizQuestions].category}知识测验</h2>
                  <p className="text-gray-600 dark:text-gray-400 mb-4">
                    {quizQuestions[key as keyof typeof quizQuestions].description}
                  </p>
                  <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                    <i className="fa-solid fa-question-circle mr-2"></i>
                    <span>共 {quizQuestions[key as keyof typeof quizQuestions].questions.length} 道题目，每题20分，满分100分</span>
                  </div>
                </div>
                
                {/* 测验内容区域 */}
                <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
                  {!quizCompleted ? (
                    <>
                      {/* 当前题目 */}
                      <div className="mb-8">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-xl font-bold">
                            问题 {currentQuestion + 1}/{quizQuestions[key as keyof typeof quizQuestions].questions.length}
                          </h3>
                          <div className="text-sm text-gray-500 dark:text-gray-400">
                            分值: 20分
                          </div>
                        </div>
                        <p className="text-lg mb-6">
                          {quizQuestions[key as keyof typeof quizQuestions].questions[currentQuestion].question}
                        </p>
                        
                        {/* 选项 */}
                        <div className="space-y-3 mb-8">
                          {quizQuestions[key as keyof typeof quizQuestions].questions[currentQuestion].options.map((option) => (
                            <motion.div
                              key={option.id}
                              whileHover={{ scale: 1.01 }}
                              whileTap={{ scale: 0.99 }}
                              onClick={() => handleAnswerSelect(option.id)}
                              className={`p-4 rounded-lg cursor-pointer border transition-all duration-300 ${
                                selectedAnswers[currentQuestion] === option.id
                                  ? isDark 
                                    ? 'border-blue-500 bg-blue-900/30' 
                                    : 'border-blue-500 bg-blue-50'
                                  : isDark 
                                    ? 'border-gray-700 hover:border-blue-500/50' 
                                    : 'border-gray-200 hover:border-blue-500'
                              }`}
                            >
                              <div className="flex items-center">
                                <div className={`w-6 h-6 rounded-full flex items-center justify-center mr-3 border ${
                                  selectedAnswers[currentQuestion] === option.id
                                    ? 'border-blue-500 bg-blue-500 text-white'
                                    : isDark 
                                      ? 'border-gray-600' 
                                      : 'border-gray-300'
                                }`}>
                                  {option.id}
                                </div>
                                <span>{option.text}</span>
                              </div>
                            </motion.div>
                          ))}
                        </div>
                      </div>
                      
                      {/* 导航按钮 */}
                      <div className="flex justify-between">
                        <button
                          onClick={handlePrevQuestion}
                          disabled={currentQuestion === 0}
                          className={`px-6 py-3 rounded-lg font-medium transition-all duration-300 ${
                            currentQuestion === 0
                              ? 'opacity-50 cursor-not-allowed bg-gray-200 dark:bg-gray-700'
                              : isDark 
                                ? 'bg-gray-700 hover:bg-gray-600' 
                                : 'bg-gray-200 hover:bg-gray-300'
                          }`}
                        >
                          上一题
                        </button>
                        <button
                          onClick={handleNextQuestion}
                          disabled={!selectedAnswers[currentQuestion]}
                          className={`px-6 py-3 rounded-lg font-medium transition-all duration-300 ${
                            !selectedAnswers[currentQuestion]
                              ? 'opacity-50 cursor-not-allowed bg-blue-400 text-white'
                              : 'bg-blue-600 hover:bg-blue-700 text-white'
                          }`}
                        >
                          {currentQuestion < quizQuestions[key as keyof typeof quizQuestions].questions.length - 1 
                            ? '下一题' 
                            : '提交答案'
                          }
                        </button>
                      </div>
                    </>
                  ) : (
                    <>
                      {/* 测验结果 */}
                      <div className="text-center mb-8">
                        <div className="w-24 h-24 bg-blue-600 rounded-full flex items-center justify-center text-white text-3xl font-bold mx-auto mb-4">
                          {score * 20}
                        </div>
                        <h3 className="text-2xl font-bold mb-2">测验完成！</h3>
                        <p className="text-lg text-gray-600 dark:text-gray-400 mb-6">
                          您在{quizQuestions[key as keyof typeof quizQuestions].category}测验中获得了 {score * 20} 分
                        </p>
                        
                        {/* 饼图显示 */}
                        <div className="w-48 h-48 mx-auto mb-6">
                          <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                              <Pie
                                data={pieData}
                                cx="50%"
                                cy="50%"
                                innerRadius={40}
                                outerRadius={70}
                                fill="#8884d8"
                                paddingAngle={2}
                                dataKey="value"
                              >
                                {pieData.map((entry, index) => (
                                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                                ))}
                              </Pie>
                            </PieChart>
                          </ResponsiveContainer>
                          <div className="flex justify-center space-x-6 mt-2">
                            <div className="flex items-center">
                              <div className="w-3 h-3 rounded-full bg-green-500 mr-2"></div>
                              <span className="text-sm">正确: {score}</span>
                            </div>
                            <div className="flex items-center">
                              <div className="w-3 h-3 rounded-full bg-red-500 mr-2"></div>
                              <span className="text-sm">错误: {quizQuestions[key as keyof typeof quizQuestions].questions.length - score}</span>
                            </div>
                          </div>
                        </div>
                        
                        {/* 评价 */}
                        <div className={`inline-block px-6 py-3 rounded-full text-white font-medium ${
                          score * 20 >= 90 ? 'bg-green-600' :
                          score * 20 >= 70 ? 'bg-blue-600' :
                          score * 20 >= 60 ? 'bg-yellow-600' :
                          'bg-red-600'
                        }`}>
                          {score * 20 >= 90 ? '优秀' :
                           score * 20 >= 70 ? '良好' :
                           score * 20 >= 60 ? '及格' :
                           '需要加强'}
                        </div>
                      </div>
                      
                      {/* 错题解析 */}
                      {(quizQuestions[key as keyof typeof quizQuestions].questions.length - score) > 0 && (
                        <div className="mb-8">
                          <h3 className="text-xl font-bold mb-4">错题解析</h3>
                          <div className="space-y-6">
                            {quizQuestions[key as keyof typeof quizQuestions].questions.map((q, index) => {
                              const selectedOption = q.options.find(opt => opt.id === selectedAnswers[index]);
                              if (!selectedOption || selectedOption.isCorrect) return null;
                              
                              const correctOption = q.options.find(opt => opt.isCorrect);
                              
                              return (
                                <div key={q.id} className={`p-4 rounded-lg border border-red-500 ${isDark ? 'bg-red-900/20' : 'bg-red-50'}`}>
                                  <p className="font-medium mb-3">问题 {index + 1}: {q.question}</p>
                                  <p className="text-red-600 dark:text-red-400 mb-2">
                                    您的答案: {selectedOption.id}. {selectedOption.text}
                                  </p>
                                  <p className="text-green-600 dark:text-green-400 mb-2">
                                    正确答案: {correctOption?.id}. {correctOption?.text}
                                  </p>
                                  <p className="text-sm text-gray-600 dark:text-gray-400">
                                    解析: {index === 0 && '型腔是模具中直接形成制品形状的部分，是模具的核心组件。'}
                                    {index === 1 && '注塑模专门用于生产塑料零件，通过将熔融塑料注入模具型腔成型。'}
                                    {index === 2 && '导柱和导套确保动模和定模在开合过程中的精确导向和定位。'}
                                    {index === 3 && '锻造是一种金属压力加工方法，不是注塑成型的阶段。'}
                                    {index === 4 && '脱模斜度可以减少制品与模具之间的摩擦，便于制品顺利脱模。'}
                                  </p>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}
                      
                      {/* 按钮组 */}
                      <div className="flex flex-col sm:flex-row justify-center gap-4">
                        <button
                          onClick={resetQuiz}
                          className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all duration-300"
                        >
                          重新测验
                        </button>
                        <button
                          onClick={() => setActiveCategory('basics')}
                          className={`px-6 py-3 rounded-lg font-medium transition-all duration-300 ${
                            isDark 
                              ? 'bg-gray-700 hover:bg-gray-600' 
                              : 'bg-gray-200 hover:bg-gray-300'
                          }`}
                        >
                          选择其他分类
                        </button>
                        <button className="px-6 py-3 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-all duration-300">
                          查看学习资料
                        </button>
                      </div>
                    </>
                  )}
                </div>
                
                {/* 测试历史 */}
                <div className={`mt-8 p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
                  <h2 className="text-2xl font-bold mb-4">测试历史</h2>
                  
                  {testHistory.length > 0 ? (
                    <div className="space-y-4">
                      {testHistory.map((test, index) => (
                        <div 
                          key={index} 
                          className={`p-4 rounded-lg transition-all duration-300 ${
                            isDark ? 'bg-gray-700' : 'bg-gray-50'
                          }`}
                        >
                          <div className="flex justify-between items-center mb-2">
                            <h4 className="font-bold">{test.category}</h4>
                            <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                              test.score >= 90 ? 'bg-green-500 text-white' :
                              test.score >= 70 ? 'bg-blue-500 text-white' :
                              test.score >= 60 ? 'bg-yellow-500 text-white' :
                              'bg-red-500 text-white'
                            }`}>
                              得分: {test.score}
                            </div>
                          </div>
                          <div className="flex justify-between items-center text-sm text-gray-600 dark:text-gray-400">
                            <span>测试日期: {test.date}</span>
                            <button className="text-blue-600 dark:text-blue-400 hover:underline">
                              查看详情
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                      暂无测试历史记录
                    </div>
                  )}
                </div>
              </motion.div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </div>
  );
}