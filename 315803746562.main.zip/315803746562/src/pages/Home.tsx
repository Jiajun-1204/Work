import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ChevronRight } from 'lucide-react';
import { useTheme } from '@/hooks/useTheme';

export default function Home() {
  const { theme, toggleTheme, isDark } = useTheme();
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  // 动画变体
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: { duration: 0.5 }
    }
  };

  const features = [
    {
      id: 1,
      title: "注塑成型原理",
      description: "以动画和交互式步骤展示注塑全过程，包括熔体流动路径、冷却系统和顶出机构。",
      icon: "fa-industry",
      path: "/injection-molding"
    },
    {
      id: 2,
      title: "模具结构与零件",
      description: "详细展示模具核心组件的3D结构图、装配关系和功能说明。",
      icon: "fa-cogs",
      path: "/mold-structure"
    },
    {
      id: 3,
      title: "模具加工工艺",
      description: "全面介绍CNC加工、电火花、线切割、磨削和抛光等制造工艺。",
      icon: "fa-tools",
      path: "/processing-technology"
    },
    {
      id: 4,
      title: "材料与热处理",
      description: "提供模具材料数据库和热处理工艺详解，帮助选择最优材料方案。",
      icon: "fa-microchip",
      path: "/materials-database"
    },
    {
      id: 5,
      title: "交互式学习工具",
      description: "3D模具拆解模拟器、材料选择计算器和工艺路线规划流程图。",
      icon: "fa-vr-cardboard",
      path: "/learning-tools"
    },
    {
      id: 6,
      title: "知识测验",
      description: "通过练习题和知识测验巩固学习效果，检验掌握程度。",
      icon: "fa-graduation-cap",
      path: "/knowledge-quiz"
    }
  ];

  // 学习路径数据
  const learningPaths = [
    {
      title: "入门学习路径",
      description: "适合模具行业初学者，从基础概念到简单应用",
      steps: ["模具基础概念", "注塑成型原理", "简单模具结构", "常用材料介绍"],
      color: "bg-blue-500"
    },
    {
      title: "进阶工程师路径",
      description: "适合有一定经验的工程师，深入学习模具设计与制造",
      steps: ["复杂模具结构", "加工工艺优化", "材料选择策略", "模具寿命提升"],
      color: "bg-green-500"
    },
    {
      title: "专家认证路径",
      description: "适合资深工程师，掌握前沿技术和解决方案",
      steps: ["先进模具设计", "CAE模拟分析", "特殊成型工艺", "质量管理体系"],
      color: "bg-purple-500"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100 dark:from-gray-900 dark:to-gray-800 text-gray-800 dark:text-gray-200">
      {/* 英雄区域 */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 dark:from-blue-900/40 dark:to-purple-900/40"></div>
          <div 
            className="absolute inset-0 bg-[url('https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=mold%20manufacturing%20process%2C%20injection%20molding%20machine%2C%20industrial%20equipment%2C%20modern%20factory&sign=d703969b16e9ba63c717aa8bbed25fa7')] bg-cover bg-center"
            style={{ filter: 'brightness(0.7)' }}
          ></div>
        </div>
        
        <div className="container mx-auto px-4 py-20 md:py-32 relative z-10">
          <motion.div 
            className="max-w-3xl mx-auto text-center"
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400">
              模具工作流程学习平台
            </h1>
            <p className="text-xl md:text-2xl mb-10 text-gray-700 dark:text-gray-300">
              探索注塑成型的奥秘，掌握模具设计与制造的核心技术
            </p>
            <div className="flex flex-wrap justify-center gap-4">
              <Link to="/injection-molding" className="px-8 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-full transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1">
                开始学习
              </Link>
              <Link to="/learning-tools" className="px-8 py-3 bg-white hover:bg-gray-100 text-blue-600 font-medium rounded-full transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1 dark:bg-gray-800 dark:hover:bg-gray-700 dark:text-blue-400">
                探索工具
              </Link>
            </div>
          </motion.div>
        </div>
        
        <div className="absolute bottom-0 left-0 w-full h-24 bg-gradient-to-t from-gray-50 to-transparent dark:from-gray-900"></div>
      </section>

      {/* 特色功能区域 */}
      <section className="py-16 md:py-24 container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">核心学习内容</h2>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            我们提供全面的模具工程知识体系，从基础原理到高级应用
          </p>
        </div>
        
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
          variants={containerVariants}
          initial="hidden"
          animate={mounted ? "visible" : "hidden"}
        >
          {features.map((feature) => (
            <motion.div
              key={feature.id}
              variants={itemVariants}
              className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 border border-gray-100 dark:border-gray-700 group"
            >
              <div className="p-8">
                <div className="w-14 h-14 bg-blue-100 dark:bg-blue-900/50 rounded-full flex items-center justify-center mb-6 text-blue-600 dark:text-blue-400 group-hover:bg-blue-600 group-hover:text-white dark:group-hover:bg-blue-600 dark:group-hover:text-white transition-all duration-300">
                  <i className={`fa-solid ${feature.icon} text-2xl`}></i>
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-gray-600 dark:text-gray-400 mb-6">{feature.description}</p>
                <Link 
                  to={feature.path} 
                  className="inline-flex items-center text-blue-600 dark:text-blue-400 font-medium hover:text-blue-800 dark:hover:text-blue-300 transition-colors duration-300"
                >
                  了解更多 <ChevronRight size={18} className="ml-1 group-hover:translate-x-1 transition-transform duration-300" />
                </Link>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </section>

      {/* 学习路径区域 */}
      <section className="py-16 bg-gray-100 dark:bg-gray-800">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">定制学习路径</h2>
            <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
              根据您的经验水平和职业目标，选择最适合您的学习路径
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {learningPaths.map((path, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                className="bg-white dark:bg-gray-700 rounded-xl shadow-lg overflow-hidden border border-gray-100 dark:border-gray-600 hover:shadow-xl transition-all duration-300"
              >
                <div className={`h-3 ${path.color}`}></div>
                <div className="p-8">
                  <h3 className="text-xl font-bold mb-3">{path.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400 mb-6">{path.description}</p>
                  <ul className="space-y-3 mb-8">
                    {path.steps.map((step, stepIndex) => (
                      <li key={stepIndex} className="flex items-start">
                        <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-3"></i>
                        <span>{step}</span>
                      </li>
                    ))}
                  </ul>
                  <Link 
                    to="/learning-tools" 
                    className={`block text-center py-3 rounded-lg font-medium ${path.color} text-white hover:opacity-90 transition-opacity duration-300`}
                  >
                    开始学习路径
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* 交互式学习工具区域 */}
      <section className="py-16 md:py-24 container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">交互式学习工具</h2>
          <p className="text-xl text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            通过实践操作加深理解，提升技能水平
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <motion.div 
            className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden border border-gray-100 dark:border-gray-700"
            initial={{ opacity: 0, x: -30 }}
            animate={mounted ? { opacity: 1, x: 0 } : { opacity: 0, x: -30 }}
            transition={{ duration: 0.6 }}
          >
            <div className="h-64 overflow-hidden">
              <img 
                src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=3D%20mold%20simulation%2C%20interactive%20disassembly%2C%20engineering%20software%2C%20mold%20parts&sign=acbe4055a84f1f28b6f0e5830346ab5f" 
                alt="3D模具拆解模拟器" 
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
              />
            </div>
            <div className="p-8">
              <h3 className="text-xl font-bold mb-3">3D模具拆解模拟器</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                交互式3D模型，让您可以逐层拆解模具，观察各部件的装配关系和空间布局。
              </p>
              <Link 
                to="/learning-tools" 
                className="inline-flex items-center text-blue-600 dark:text-blue-400 font-medium hover:text-blue-800 dark:hover:text-blue-300 transition-colors duration-300"
              >
                开始使用 <ChevronRight size={18} className="ml-1" />
              </Link>
            </div>
          </motion.div>
          
          <motion.div 
            className="bg-white dark:bg-gray-800 rounded-xl shadow-lg overflow-hidden border border-gray-100 dark:border-gray-700"
            initial={{ opacity: 0, x: 30 }}
            animate={mounted ? { opacity: 1, x: 0 } : { opacity: 0, x: 30 }}
            transition={{ duration: 0.6 }}
          >
            <div className="h-64 overflow-hidden">
              <img 
                src="https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=material%20selection%20calculator%2C%20engineering%20software%2C%20data%20analysis%2C%20material%20properties&sign=adcebf168d57e1f154f55750bf37490d" 
                alt="材料选择计算器" 
                className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
              />
            </div>
            <div className="p-8">
              <h3 className="text-xl font-bold mb-3">材料选择计算器</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-6">
                根据产品要求、产量和成本预算，智能推荐最优的模具材料和热处理方案。
              </p>
              <Link 
                to="/learning-tools" 
                className="inline-flex items-center text-blue-600 dark:text-blue-400 font-medium hover:text-blue-800 dark:hover:text-blue-300 transition-colors duration-300"
              >
                开始使用 <ChevronRight size={18} className="ml-1" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* 知识测验区域 */}
      <section className="py-16 bg-gradient-to-b from-gray-100 to-gray-50 dark:from-gray-800 dark:to-gray-900">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden border border-gray-100 dark:border-gray-700">
            <div className="md:flex">
              <div className="md:w-1/2">
                <div className="h-full p-8 flex flex-col justify-center">
                  <h2 className="text-3xl font-bold mb-4">检验您的学习成果</h2>
                  <p className="text-gray-600 dark:text-gray-400 mb-8">
                    通过我们的知识测验系统，测试您对模具工程知识的掌握程度，巩固学习效果。
                  </p>
                  <Link 
                    to="/knowledge-quiz" 
                    className="inline-flex items-center justify-center px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all duration-300 shadow-md hover:shadow-lg w-full md:w-auto"
                  >
                    开始测验
                  </Link>
                </div>
              </div>
              <div className="md:w-1/2 h-64 md:h-auto">
                <img 
                  src="https://space.coze.cn/api/coze_space/gen_image?image_size=portrait_4_3&prompt=knowledge%20quiz%20interface%2C%20interactive%20learning%20platform%2C%20education%20software&sign=9015f868f11bc857f85ff311b089db5d" 
                  alt="知识测验" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}