import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/Tabs';

export default function LearningTools() {
  const { isDark } = useTheme();
  const [activeTool, setActiveTool] = useState('disassembly');
  const [isDragging, setIsDragging] = useState(false);
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 });
  const [selectedPart, setSelectedPart] = useState<string | null>(null);
  const modelRef = useRef<HTMLDivElement>(null);
  
  // 3D模具拆解模拟器数据
  const moldParts = [
    { id: 'fixed_plate', name: '定模座板', position: { x: 0, y: 0 }, color: '#3b82f6' },
    { id: 'cavity_insert', name: '型腔镶件', position: { x: 0, y: 0 }, color: '#10b981' },
    { id: 'core_insert', name: '型芯镶件', position: { x: 0, y: 0 }, color: '#f59e0b' },
    { id: 'moving_plate', name: '动模座板', position: { x: 0, y: 0 }, color: '#ef4444' },
    { id: 'ejector_plate', name: '顶出板', position: { x: 0, y: 0 }, color: '#8b5cf6' },
    { id: 'guide_pillar', name: '导柱', position: { x: 0, y: 0 }, color: '#ec4899' },
    { id: 'runner_system', name: '流道系统', position: { x: 0, y: 0 }, color: '#6366f1' }
  ];
  
  // 材料选择计算器数据
  const materialCalculatorData = {
    productRequirements: [
      { name: '产品类型', options: ['塑胶产品', '五金产品', '复合材料'] },
      { name: '预计产量', options: ['小批量(<10,000)', '中批量(10,000-100,000)', '大批量(>100,000)'] },
      { name: '表面要求', options: ['普通表面', '一般抛光', '镜面抛光'] },
      { name: '尺寸精度', options: ['低精度', '中等精度', '高精度'] }
    ],
    costBudget: [
      { name: '模具总成本', options: ['<5万元', '5-15万元', '>15万元'] },
      { name: '材料成本占比', min: 10, max: 50, default: 30 },
      { name: '交货周期', options: ['紧急(<2周)', '标准(2-4周)', '宽松(>4周)'] }
    ],
    recommendations: [
      {
        material: 'S136',
        description: '高耐磨、高耐腐蚀的镜面模具钢',
        score: 90,
        cost: '中高',
        suitable: true
      },
      {
        material: '718H',
        description: '预硬型塑料模具钢，加工性能好',
        score: 85,
        cost: '中等',
        suitable: true
      },
      {
        material: 'NAK80',
        description: '析出硬化型塑料模具钢，镜面性好',
        score: 88,
        cost: '中高',
        suitable: true
      },
      {
        material: 'P20',
        description: '一般塑料模具钢，成本较低',
        score: 75,
        cost: '低',
        suitable: false
      }
    ]
  };
  
  // 工艺路线规划流程图数据
  const processRouteData = {
    steps: [
      { id: 1, name: '设计阶段', duration: '3-7天', dependencies: [] },
      { id: 2, name: '材料准备', duration: '1-3天', dependencies: [1] },
      { id: 3, name: 'CNC粗加工', duration: '2-5天', dependencies: [2] },
      { id: 4, name: '热处理', duration: '1-3天', dependencies: [3] },
      { id: 5, name: 'CNC精加工', duration: '3-7天', dependencies: [4] },
      { id: 6, name: '电火花加工', duration: '2-5天', dependencies: [4] },
      { id: 7, name: '线切割加工', duration: '1-3天', dependencies: [4] },
      { id: 8, name: '磨削加工', duration: '1-3天', dependencies: [5, 6, 7] },
      { id: 9, name: '抛光', duration: '2-5天', dependencies: [8] },
      { id: 10, name: '组装调试', duration: '2-5天', dependencies: [9] }
    ]
  };
  
  // 模拟拖动功能
  const handleDragStart = (e: React.MouseEvent, partId: string) => {
    setIsDragging(true);
    setSelectedPart(partId);
    const rect = modelRef.current?.getBoundingClientRect();
    if (rect) {
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      });
    }
  };
  
  const handleDragMove = (e: React.MouseEvent) => {
    if (!isDragging || !modelRef.current) return;
    
    const rect = modelRef.current.getBoundingClientRect();
    const part = moldParts.find(p => p.id === selectedPart);
    if (part) {
      part.position = {
        x: e.clientX - rect.left - dragOffset.x,
        y: e.clientY - rect.top - dragOffset.y
      };
    }
  };
  
  const handleDragEnd = () => {
    setIsDragging(false);
  };
  
  useEffect(() => {
    if (isDragging) {
      document.addEventListener('mousemove', handleDragMove);
      document.addEventListener('mouseup', handleDragEnd);
      return () => {
        document.removeEventListener('mousemove', handleDragMove);
        document.removeEventListener('mouseup', handleDragEnd);
      };
    }
  }, [isDragging, dragOffset]);
  
  // 重置模具零件位置
  const resetParts = () => {
    moldParts.forEach(part => {
      part.position = { x: 0, y: 0 };
    });
    setSelectedPart(null);
  };
  
  // 爆炸视图
  const explodeView = () => {
    const positions = [
      { x: 0, y: -100 },
      { x: 0, y: -50 },
      { x: 0, y: 50 },
      { x: 0, y: 100 },
      { x: 0, y: 150 },
      { x: -100, y: 0 },
      { x: 100, y: 0 }
    ];
    
    moldParts.forEach((part, index) => {
      part.position = positions[index % positions.length];
    });
  };
  
  return (
    <div className="min-h-screen pt-24 pb-16 bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-200">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto mb-12 text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400">
            交互式学习工具
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-400">
            通过实践操作加深对模具工程知识的理解和掌握
          </p>
        </div>
        
        {/* 主要内容区域 */}
        <Tabs defaultValue="disassembly" className="w-full" onValueChange={setActiveTool}>
          <div className="flex justify-center mb-8">
            <TabsList className={`p-1 rounded-xl ${isDark ? 'bg-gray-800' : 'bg-gray-100'}`}>
              <TabsTrigger 
                value="disassembly" 
                className={`px-6 py-2 rounded-lg transition-all duration-300 ${
                  activeTool === 'disassembly' 
                    ? 'bg-blue-600 text-white font-medium' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                3D模具拆解模拟器
              </TabsTrigger>
              <TabsTrigger 
                value="material" 
                className={`px-6 py-2 rounded-lg transition-all duration-300 ${
                  activeTool === 'material' 
                    ? 'bg-blue-600 text-white font-medium' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                材料选择计算器
              </TabsTrigger>
              <TabsTrigger 
                value="process" 
                className={`px-6 py-2 rounded-lg transition-all duration-300 ${
                  activeTool === 'process' 
                    ? 'bg-blue-600 text-white font-medium' 
                    : 'hover:bg-gray-200 dark:hover:bg-gray-700'
                }`}
              >
                工艺路线规划
              </TabsTrigger>
            </TabsList>
          </div>
          
          {/* 3D模具拆解模拟器内容 */}
          <TabsContent value="disassembly" className="mt-0">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* 左侧：模具零件列表 */}
                <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
                  <h2 className="text-2xl font-bold mb-6">模具零件</h2>
                  
                  <div className="space-y-3">
                    {moldParts.map((part) => (
                      <motion.div
                        key={part.id}
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={() => setSelectedPart(part.id)}
                        className={`p-3 rounded-lg cursor-pointer transition-all duration-300 ${
                          selectedPart === part.id
                            ? 'bg-blue-600 text-white shadow-md'
                            : isDark 
                              ? 'bg-gray-700 hover:bg-gray-600' 
                              : 'bg-gray-100 hover:bg-gray-200'
                        }`}
                      >
                        <div className="flex items-center">
                          <div 
                            className="w-4 h-4 rounded-full mr-3" 
                            style={{ backgroundColor: part.color }}
                          ></div>
                          <span>{part.name}</span>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                  
                  <div className="mt-8 space-y-4">
                    <h3 className="text-xl font-bold mb-4">操作工具</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <button 
                        onClick={explodeView}
                        className="py-3 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all duration-300"
                      >
                        <i className="fa-solid fa-explosion mr-2"></i> 爆炸视图
                      </button>
                      <button 
                        onClick={resetParts}
                        className="py-3 px-4 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-all duration-300"
                      >
                        <i className="fa-solid fa-undo mr-2"></i> 重置位置
                      </button>
                    </div>
                    <button className="py-3 px-4 w-full bg-green-600 hover:bg-green-700 text-white font-medium rounded-lg transition-all duration-300">
                      <i className="fa-solid fa-play mr-2"></i> 观看装配动画
                    </button>
                  </div>
                </div>
                
                {/* 右侧：3D模型显示区域 */}
                <div className="lg:col-span-2">
                  <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} h-full`}>
                    <h2 className="text-2xl font-bold mb-6">3D模具模型</h2>
                    
                    {/* 3D模型展示区 */}
                    <div 
                      ref={modelRef}
                      className="relative w-full h-[400px] md:h-[500px] mb-6 rounded-lg overflow-hidden"
                      style={{ 
                        backgroundColor: isDark ? '#1f2937' : '#f3f4f6',
                        border: '2px dashed #9ca3af'
                      }}
                    >
                      {/* 模拟3D模具模型 */}
                      <div className="absolute inset-0 flex items-center justify-center">
                        {/* 这里是模拟的3D模型，实际项目中应替换为真正的3D模型组件 */}
                        <div className="relative w-3/4 h-3/4">
                          {moldParts.map((part) => (
                            <motion.div
                              key={part.id}
                              style={{
                                x: part.position.x,
                                y: part.position.y,
                                backgroundColor: part.color,
                                opacity: selectedPart && selectedPart !== part.id ? 0.5 : 1
                              }}
                              className={`absolute cursor-move transition-opacity duration-300`}
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedPart(part.id);
                              }}
                              onMouseDown={(e) => {
                                e.stopPropagation();
                                handleDragStart(e, part.id);
                              }}
                            >
                              {part.id === 'fixed_plate' && (
                                <div className="w-64 h-16 rounded-lg bg-opacity-80 flex items-center justify-center text-white font-bold">
                                  定模座板
                                </div>
                              )}
                              {part.id === 'cavity_insert' && (
                                <div className="w-56 h-12 rounded-lg bg-opacity-80 flex items-center justify-center text-white font-bold">
                                  型腔镶件
                                </div>
                              )}
                              {part.id === 'core_insert' && (
                                <div className="w-52 h-10 rounded-lg bg-opacity-80 flex items-center justify-center text-white font-bold">
                                  型芯镶件
                                </div>
                              )}
                              {part.id === 'moving_plate' && (
                                <div className="w-64 h-16 rounded-lg bg-opacity-80 flex items-center justify-center text-white font-bold">
                                  动模座板
                                </div>
                              )}
                              {part.id === 'ejector_plate' && (
                                <div className="w-60 h-14 rounded-lg bg-opacity-80 flex items-center justify-center text-white font-bold">
                                  顶出板
                                </div>
                              )}
                              {part.id === 'guide_pillar' && (
                                <div className="w-4 h-60 rounded-full bg-opacity-80"></div>
                              )}
                              {part.id === 'runner_system' && (
                                <div className="w-28 h-8 rounded-lg bg-opacity-80 flex items-center justify-center text-white font-bold">
                                  流道系统
                                </div>
                              )}
                            </motion.div>
                          ))}
                        </div>
                      </div>
                      
                      {/* 操作提示 */}
                      <div className="absolute bottom-4 left-4 right-4 bg-black/50 text-white p-3 rounded-lg">
                        <p className="text-sm">
                          <i className="fa-solid fa-mouse-pointer mr-2"></i> 
                          点击选择零件，拖动调整位置
                        </p>
                      </div>
                    </div>
                    
                    {/* 零件详情 */}
                    {selectedPart && (
                      <div className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                        <h3 className="text-xl font-bold mb-2">
                          {moldParts.find(p => p.id === selectedPart)?.name}
                        </h3>
                        <p className="text-gray-600 dark:text-gray-400 mb-4">
                          {selectedPart === 'fixed_plate' && '定模座板是模具的固定部分，与注塑机的定模板相连，支撑定模部分的所有组件。'}
                          {selectedPart === 'cavity_insert' && '型腔镶件是形成制品外表面的零件，通常需要高精度加工和抛光处理。'}
                          {selectedPart === 'core_insert' && '型芯镶件是形成制品内表面的零件，其形状取决于制品的内部结构。'}
                          {selectedPart === 'moving_plate' && '动模座板是模具的移动部分，与注塑机的动模板相连，支撑动模部分的所有组件。'}
                          {selectedPart === 'ejector_plate' && '顶出板用于固定顶针等顶出元件，在注塑机顶出机构的推动下将制品推出型腔。'}
                          {selectedPart === 'guide_pillar' && '导柱用于保证动模和定模的精确导向和定位，防止模具合模时错位。'}
                          {selectedPart === 'runner_system' && '流道系统是塑料熔体从注塑机射嘴进入模具型腔的通道，包括主流道、分流道和浇口。'}
                        </p>
                        <div className="grid grid-cols-2 gap-4">
                          <button className="py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all duration-300">
                            <i className="fa-solid fa-info-circle mr-2"></i> 查看详细信息
                          </button>
                          <button className="py-2 px-4 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-all duration-300">
                            <i className="fa-solid fa-tools mr-2"></i> 查看装配要求
                          </button>
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </motion.div>
          </TabsContent>
          
          {/* 材料选择计算器内容 */}
          <TabsContent value="material" className="mt-0">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} mb-8`}>
                <h2 className="text-2xl font-bold mb-6">材料选择计算器</h2>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* 左侧：输入参数 */}
                  <div>
                    <h3 className="text-xl font-bold mb-4">输入参数</h3>
                    
                    {/* 产品要求 */}
                    <div className="mb-8">
                      <h4 className="font-semibold mb-3">产品要求</h4>
                      <div className="space-y-4">
                        {materialCalculatorData.productRequirements.map((req, index) => (
                          <div key={index}>
                            <label className="block text-sm font-medium mb-1">{req.name}</label>
                            {req.options ? (
                              <select className={`w-full p-2 rounded-lg border ${
                                isDark 
                                  ? 'bg-gray-700 border-gray-600' 
                                  : 'bg-white border-gray-300'
                              }`}>
                                {req.options.map((opt, optIndex) => (
                                  <option key={optIndex}>{opt}</option>
                                ))}
                              </select>
                            ) : null}
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    {/* 成本预算 */}
                    <div>
                      <h4 className="font-semibold mb-3">成本预算</h4>
                      <div className="space-y-4">
                        {materialCalculatorData.costBudget.map((budget, index) => (
                          <div key={index}>
                            <label className="block text-sm font-medium mb-1">{budget.name}</label>
                            {budget.options ? (
                              <select className={`w-full p-2 rounded-lg border ${
                                isDark 
                                  ? 'bg-gray-700 border-gray-600' 
                                  : 'bg-white border-gray-300'
                              }`}>
                                {budget.options.map((opt, optIndex) => (
                                  <option key={optIndex}>{opt}</option>
                                ))}
                              </select>
                            ) : (
                              <>
                                <input 
                                  type="range" 
                                  min={budget.min} 
                                  max={budget.max} 
                                  defaultValue={budget.default}
                                  className="w-full h-2 bg-gray-300 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
                                />
                                <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400 mt-1">
                                  <span>{budget.min}%</span>
                                  <span>{budget.default}%</span>
                                  <span>{budget.max}%</span>
                                </div>
                              </>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    {/* 计算按钮 */}
                    <div className="mt-8">
                      <button className="w-full py-3 px-6 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all duration-300">
                        <i className="fa-solid fa-calculator mr-2"></i> 计算最佳材料
                      </button>
                    </div>
                  </div>
                  
                  {/* 右侧：推荐结果 */}
                  <div>
                    <h3 className="text-xl font-bold mb-4">材料推荐结果</h3>
                    
                    {/* 雷达图展示性能对比 */}
                    <div className="mb-8 bg-gray-100 dark:bg-gray-700 rounded-lg p-4 h-64 flex items-center justify-center">
                      <div className="text-center">
                        <i className="fa-solid fa-chart-radar text-4xl text-blue-600 mb-3"></i>
                        <p className="text-gray-600 dark:text-gray-400">材料性能对比雷达图</p>
                      </div>
                    </div>
                    
                    {/* 推荐材料列表 */}
                    <div className="space-y-4">
                      {materialCalculatorData.recommendations.map((rec, index) => (
                        <div 
                          key={index} 
                          className={`p-4 rounded-lg transition-all duration-300 border ${
                            rec.suitable 
                              ? isDark ? 'bg-green-900/30 border-green-700' : 'bg-green-50 border-green-200'
                              : isDark ? 'bg-gray-700 border-gray-600' : 'bg-gray-50 border-gray-200'
                          }`}
                        >
                          <div className="flex justify-between items-start mb-2">
                            <h4 className="font-bold text-lg">{rec.material}</h4>
                            <div className={`px-3 py-1 rounded-full text-xs font-medium ${
                              rec.suitable 
                                ? 'bg-green-500 text-white' 
                                : 'bg-gray-500 text-white'
                            }`}>
                              得分: {rec.score}
                            </div>
                          </div>
                          <p className="text-gray-600 dark:text-gray-400 mb-2">{rec.description}</p>
                          <div className="flex justify-between items-center">
                            <span className={`text-sm font-medium ${
                              rec.cost === '低' ? 'text-green-600 dark:text-green-400' :
                              rec.cost === '中等' ? 'text-blue-600 dark:text-blue-400' :
                              'text-purple-600 dark:text-purple-400'
                            }`}>
                              成本: {rec.cost}
                            </span>
                            {rec.suitable && (
                              <span className="text-xs font-medium text-green-600 dark:text-green-400">
                                <i className="fa-solid fa-check-circle mr-1"></i> 推荐
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                    
                    {/* 详细报告按钮 */}
                    <div className="mt-6">
                      <button className="w-full py-3 px-6 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-all duration-300">
                        <i className="fa-solid fa-file-pdf mr-2"></i> 生成详细报告
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* 使用指南 */}
              <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
                <h2 className="text-2xl font-bold mb-4">材料选择指南</h2>
                <p className="text-gray-600 dark:text-gray-400 mb-6">
                  材料选择是模具设计和制造中的关键环节，直接影响模具的性能、寿命和成本。以下是一些材料选择的基本原则：
                </p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                    <h3 className="text-lg font-semibold mb-3">考虑因素</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-3"></i>
                        <span className="text-gray-600 dark:text-gray-400">产品类型和要求</span>
                      </li>
                      <li className="flex items-start">
                        <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-3"></i>
                        <span className="text-gray-600 dark:text-gray-400">预计生产批量</span>
                      </li>
                      <li className="flex items-start">
                        <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-3"></i>
                        <span className="text-gray-600 dark:text-gray-400">模具结构复杂度</span>
                      </li>
                      <li className="flex items-start">
                        <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-3"></i>
                        <span className="text-gray-600 dark:text-gray-400">加工工艺要求</span>
                      </li>
                      <li className="flex items-start">
                        <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-3"></i>
                        <span className="text-gray-600 dark:text-gray-400">成本预算限制</span>
                      </li>
                    </ul>
                  </div>
                  
                  <div className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                    <h3 className="text-lg font-semibold mb-3">选择流程</h3>
                    <ul className="space-y-2">
                      <li className="flex items-start">
                        <i className="fa-solid fa-arrow-right text-blue-500 mt-1 mr-3"></i>
                        <span className="text-gray-600 dark:text-gray-400">确定产品和模具的基本要求</span>
                      </li>
                      <li className="flex items-start">
                        <i className="fa-solid fa-arrow-right text-blue-500 mt-1 mr-3"></i>
                        <span className="text-gray-600 dark:text-gray-400">初步筛选可能的材料选项</span>
                      </li>
                      <li className="flex items-start">
                        <i className="fa-solid fa-arrow-right text-blue-500 mt-1 mr-3"></i>
                        <span className="text-gray-600 dark:text-gray-400">评估各材料的性能和成本</span>
                      </li>
                      <li className="flex items-start">
                        <i className="fa-solid fa-arrow-right text-blue-500 mt-1 mr-3"></i>
                        <span className="text-gray-600 dark:text-gray-400">考虑热处理和表面处理工艺</span>
                      </li>
                      <li className="flex items-start">
                        <i className="fa-solid fa-arrow-right text-blue-500 mt-1 mr-3"></i>
                        <span className="text-gray-600 dark:text-gray-400">最终确定最优材料方案</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </motion.div>
          </TabsContent>
          
          {/* 工艺路线规划流程图内容 */}
          <TabsContent value="process" className="mt-0">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
                <h2 className="text-2xl font-bold mb-6">工艺路线规划流程图</h2>
                
                {/* 流程图展示区域 */}
                <div className="mb-8 bg-gray-100 dark:bg-gray-700 rounded-lg p-6 min-h-[500px]">
                  <div className="relative">
                    {/* 这里是简化的流程图表示，实际项目中可以使用更复杂的流程图库 */}
                    <div className="flex flex-wrap justify-center gap-6">
                      {processRouteData.steps.map((step) => (
                        <motion.div
                          key={step.id}
                          whileHover={{ scale: 1.05 }}
                          className={`p-4 rounded-lg shadow-md w-48 text-center ${
                            isDark ? 'bg-gray-800' : 'bg-white'
                          }`}
                          style={{
                            // 简单的布局逻辑，实际项目中可以使用更复杂的布局算法
                            position: 'relative',
                            top: Math.floor((step.id - 1) / 3) * 120,
                            left: ((step.id - 1) % 3) * 100
                          }}
                        >
                          <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center font-bold mx-auto mb-3">
                            {step.id}
                          </div>
                          <h3 className="font-bold mb-2">{step.name}</h3>
                          <p className="text-sm text-gray-600 dark:text-gray-400">{step.duration}</p>
                        </motion.div>
                      ))}
                      
                      {/* 连接线（简化表示） */}
                      <svg className="absolute top-0 left-0 w-full h-full pointer-events-none">
                        {/* 这里应该根据步骤之间的依赖关系绘制连接线 */}
                        {/* 简化版本中省略了实际的连接线绘制代码 */}
                      </svg>
                    </div>
                  </div>
                </div>
                
                {/* 工艺路线调整工具 */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* 左侧：工艺步骤调整 */}
                  <div>
                    <h3 className="text-xl font-bold mb-4">工艺步骤调整</h3>
                    
                    <div className="space-y-4">
                      <div className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                        <h4 className="font-semibold mb-3">添加新步骤</h4>
                        <div className="flex space-x-3">
                          <input 
                            type="text" 
                            placeholder="步骤名称" 
                            className={`flex-1 p-2 rounded-lg border ${
                              isDark 
                                ? 'bg-gray-800 border-gray-600' 
                                : 'bg-white border-gray-300'
                            }`}
                          />
                          <button className="py-2 px-4 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all duration-300">
                            添加
                          </button>
                        </div>
                      </div>
                      
                      <div className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                        <h4 className="font-semibold mb-3">调整顺序</h4>
                        <div className="space-y-2">
                          {processRouteData.steps.slice(0, 5).map((step) => (
                            <div key={step.id} className="flex items-center justify-between">
                              <span>{step.name}</span>
                              <div className="flex space-x-2">
                                <button className="p-1 rounded bg-gray-200 dark:bg-gray-600">
                                  <i className="fa-solid fa-arrow-up"></i>
                                </button>
                                <button className="p-1 rounded bg-gray-200 dark:bg-gray-600">
                                  <i className="fa-solid fa-arrow-down"></i>
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                      
                      <div className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                        <h4 className="font-semibold mb-3">设置依赖关系</h4>
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span>CNC精加工</span>
                            <span className="text-sm text-gray-600 dark:text-gray-400">依赖于 热处理</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span>电火花加工</span>
                            <span className="text-sm text-gray-600 dark:text-gray-400">依赖于 热处理</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* 右侧：分析结果 */}
                  <div>
                    <h3 className="text-xl font-bold mb-4">分析结果</h3>
                    
                    <div className="space-y-4">
                      <div className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                        <h4 className="font-semibold mb-3">总周期预测</h4>
                        <div className="flex items-center space-x-4">
                          <div className="w-20 h-20 rounded-full bg-blue-600 flex items-center justify-center text-white font-bold text-2xl">
                            24天
                          </div>
                          <div>
                            <p className="text-gray-600 dark:text-gray-400">基于当前工艺路线预测的总制造周期</p>
                            <div className="mt-2 h-2 w-full bg-gray-300 dark:bg-gray-600 rounded-full overflow-hidden">
                              <div className="h-full bg-blue-600 rounded-full" style={{ width: '75%' }}></div>
                            </div>
                            <div className="flex justify-between text-xs mt-1">
                              <span>0天</span>
                              <span>12天</span>
                              <span>24天</span>
                              <span>36天</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <div className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                        <h4 className="font-semibold mb-3">关键路径</h4>
                        <p className="text-gray-600 dark:text-gray-400 mb-3">
                          设计阶段 → 材料准备 → CNC粗加工 → 热处理 → CNC精加工 → 磨削加工 → 抛光 → 组装调试
                        </p>
                        <p className="text-sm text-blue-600 dark:text-blue-400">
                          <i className="fa-solid fa-lightbulb mr-1"></i> 提示：优化关键路径上的工序可以有效缩短总周期
                        </p>
                      </div>
                      
                      <div className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                        <h4 className="font-semibold mb-3">优化建议</h4>
                        <ul className="space-y-2">
                          <li className="flex items-start">
                            <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-3"></i>
                            <span className="text-gray-600 dark:text-gray-400">CNC粗加工和材料准备可以部分并行</span>
                          </li>
                          <li className="flex items-start">
                            <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-3"></i>
                            <span className="text-gray-600 dark:text-gray-400">考虑增加一台EDM设备，同时进行电火花和CNC精加工</span>
                          </li>
                          <li className="flex items-start">
                            <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-3"></i>
                            <span className="text-gray-600 dark:text-gray-400">优化抛光工艺，预计可缩短1-2天</span>
                          </li>
                        </ul>
                      </div>
                    </div>
                    
                    {/* 导出按钮 */}
                    <div className="mt-6">
                      <button className="w-full py-3 px-6 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all duration-300">
                        <i className="fa-solid fa-download mr-2"></i> 导出工艺路线图
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}