import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from '@/hooks/useTheme';

export default function InjectionMolding() {
  const { isDark } = useTheme();
  const [activeStep, setActiveStep] = useState(1);
  const [isPlaying, setIsPlaying] = useState(false);
  const animationRef = useRef<number | null>(null);
  const stepsRef = useRef<HTMLElement[]>([]);

  const steps = [
    {
      id: 1,
      title: "合模阶段",
      description: "模具的动模和定模闭合，形成封闭的型腔，准备注射塑料熔体。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=mold%20closing%20stage%2C%20injection%20molding%20machine%2C%203D%20animation&sign=1c72ec4b9d877ca3b50b00f4dcb6112e",
      details: [
        "动模向定模方向移动，直至完全闭合",
        "锁模机构提供足够的锁模力，防止注射时模具被撑开",
        "各部件处于准备注射的初始状态"
      ]
    },
    {
      id: 2,
      title: "注射阶段",
      description: "注塑机将熔融塑料通过射嘴注入模具型腔，填充整个模腔空间。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=injection%20stage%2C%20molten%20plastic%20flow%2C%20runner%20system%2C%203D%20animation&sign=3dc51e50d4b495cc2b41df63f70d2f40",
      details: [
        "螺杆向前移动，将熔融塑料通过射嘴注入模具",
        "塑料熔体依次经过主流道、分流道，最终进入型腔",
        "注射压力和速度需要精确控制，确保填充完整"
      ]
    },
    {
      id: 3,
      title: "保压阶段",
      description: "注射完成后，注塑机保持一定压力，补充因冷却收缩而减少的塑料量。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=packing%20stage%2C%20injection%20molding%2C%20pressure%20maintenance%2C%203D%20animation&sign=06883625b2caeb46bc7a8105b37e6657",
      details: [
        "螺杆保持向前的压力，持续向模腔补充熔料",
        "补偿塑料因冷却而产生的体积收缩",
        "保压时间和压力对制品尺寸精度有重要影响"
      ]
    },
    {
      id: 4,
      title: "冷却阶段",
      description: "模具内的冷却系统工作，使塑料熔体温度降低，逐渐固化成型。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=cooling%20stage%2C%20temperature%20distribution%2C%20cooling%20channels%2C%203D%20animation&sign=fd4407cb2967c3de360b4165880bca88",
      details: [
        "冷却水流过模具内的冷却水道，带走热量",
        "塑料熔体温度降至玻璃化温度以下，逐渐固化",
        "冷却时间占整个成型周期的大部分，影响生产效率"
      ]
    },
    {
      id: 5,
      title: "开模阶段",
      description: "模具的动模和定模分离，为取出制品做准备。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=mold%20opening%20stage%2C%20separating%20mold%20halves%2C%203D%20animation&sign=c6d974aa09d7f7a60395e481aa2df99c",
      details: [
        "锁模机构松开，动模开始后退",
        "模具在分型面处分开，制品留在动模一侧",
        "开模距离需要足够，确保顶出机构有足够的空间动作"
      ]
    },
    {
      id: 6,
      title: "顶出阶段",
      description: "顶出机构将固化的制品从模具型腔中推出，完成一个成型周期。",
      image: "https://space.coze.cn/api/coze_space/gen_image?image_size=landscape_16_9&prompt=ejection%20stage%2C%20ejector%20pins%20pushing%20out%20part%2C%203D%20animation&sign=c07338d737525cfb6f256daaf1d12a8c",
      details: [
        "顶出机构在开模到一定位置时开始动作",
        "顶针、司筒等部件将制品从型腔中推出",
        "制品取出后，顶出机构复位，准备下一个循环"
      ]
    }
  ];

  const startAnimation = () => {
    if (isPlaying) return;
    
    setIsPlaying(true);
    
    animationRef.current = setInterval(() => {
      setActiveStep(prev => {
        if (prev >= steps.length) {
          clearInterval(animationRef.current!);
          setIsPlaying(false);
          return 1;
        }
        return prev + 1;
      });
    }, 3000); // 每个步骤持续3秒
  };

  const stopAnimation = () => {
    if (animationRef.current) {
      clearInterval(animationRef.current);
      animationRef.current = null;
    }
    setIsPlaying(false);
  };

  useEffect(() => {
    return () => {
      if (animationRef.current) {
        clearInterval(animationRef.current);
      }
    };
  }, []);

  // 滚动到当前步骤
  useEffect(() => {
    if (stepsRef.current[activeStep - 1]) {
      stepsRef.current[activeStep - 1].scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });
    }
  }, [activeStep]);

  return (
    <div className="min-h-screen pt-24 pb-16 bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-200">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto mb-12 text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400">
            注塑成型原理可视化教学
          </h1>
          <p className="text-lg text-gray-600 dark:text-gray-400">
            通过动画和交互式步骤，深入了解注塑成型的全过程
          </p>
        </div>

        {/* 主展示区域 */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* 动画控制区 */}
          <div className="lg:col-span-1">
            <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'} sticky top-24`}>
              <h2 className="text-2xl font-bold mb-6">注塑成型流程</h2>
              
              {/* 步骤列表 */}
              <div className="space-y-2 mb-8">
                {steps.map((step, index) => (
                  <div
                    key={step.id}
                    ref={el => stepsRef.current[index] = el as HTMLElement}
                    onClick={() => {
                      stopAnimation();
                      setActiveStep(step.id);
                    }}
                    className={`p-3 rounded-lg cursor-pointer transition-all duration-300 ${
                      activeStep === step.id
                        ? 'bg-blue-600 text-white shadow-md'
                        : isDark 
                          ? 'bg-gray-700 hover:bg-gray-600' 
                          : 'bg-gray-100 hover:bg-gray-200'
                    }`}
                  >
                    <div className="flex items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center mr-3 ${
                        activeStep === step.id ? 'bg-white text-blue-600' : 'bg-gray-500 text-white'
                      }`}>
                        {step.id}
                      </div>
                      <span className={`font-medium ${activeStep === step.id ? 'text-white' : ''}`}>
                        {step.title}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              
              {/* 控制按钮 */}
              <div className="flex space-x-3">
                <button
                  onClick={isPlaying ? stopAnimation : startAnimation}
                  className={`flex-1 py-3 rounded-lg font-medium transition-all duration-300 ${
                    isPlaying
                      ? 'bg-red-600 hover:bg-red-700 text-white'
                      : 'bg-blue-600 hover:bg-blue-700 text-white'
                  }`}
                >
                  {isPlaying ? '暂停动画' : '播放动画'}
                </button>
                <button
                  onClick={() => {
                    stopAnimation();
                    setActiveStep(1);
                  }}
                  className={`py-3 px-4 rounded-lg font-medium transition-all duration-300 ${
                    isDark 
                      ? 'bg-gray-700 hover:bg-gray-600' 
                      : 'bg-gray-200 hover:bg-gray-300'
                  }`}
                >
                  重置
                </button>
              </div>
            </div>
          </div>
          
          {/* 动画展示区 */}
          <div className="lg:col-span-2">
            <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeStep}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  {/* 步骤标题 */}
                  <h3 className="text-2xl font-bold mb-4">{steps[activeStep - 1].title}</h3>
                  
                  {/* 步骤图片 */}
                  <div className="mb-6 overflow-hidden rounded-lg">
                    <motion.img
                      src={steps[activeStep - 1].image}
                      alt={steps[activeStep - 1].title}
                      className="w-full h-auto object-cover rounded-lg"
                      initial={{ scale: 1.1 }}
                      animate={{ scale: 1 }}
                      transition={{ duration: 0.5 }}
                    />
                  </div>
                  
                  {/* 步骤描述 */}
                  <div className="mb-6">
                    <p className="text-lg text-gray-600 dark:text-gray-400">
                      {steps[activeStep - 1].description}
                    </p>
                  </div>
                  
                  {/* 步骤详情 */}
                  <div className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                    <h4 className="text-lg font-semibold mb-3">关键知识点：</h4>
                    <ul className="space-y-2">
                      {steps[activeStep - 1].details.map((detail, index) => (
                        <li key={index} className="flex items-start">
                          <i className="fa-solid fa-check-circle text-green-500 mt-1 mr-3"></i>
                          <span>{detail}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
            
            {/* 交互式3D模型提示 */}
            <div className={`mt-8 p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
              <h3 className="text-xl font-bold mb-4">交互式3D模具模型</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-4">
                探索模具内部结构和各部件的运动关系，点击下方按钮进入3D交互模式。
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <button className="py-3 px-6 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-all duration-300">
                  查看3D模具模型
                </button>
                <button className="py-3 px-6 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-all duration-300">
                  观看动画演示
                </button>
              </div>
            </div>
          </div>
        </div>
        
        {/* 常见问题区域 */}
        <div className="mt-12">
          <div className={`p-6 rounded-xl shadow-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
            <h3 className="text-2xl font-bold mb-6">注塑成型常见问题解答</h3>
            <div className="space-y-4">
              <div className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                <h4 className="font-semibold mb-2">什么是注塑成型的最佳温度？</h4>
                <p className="text-gray-600 dark:text-gray-400">
                  注塑温度取决于塑料材料的类型，通常在180°C至300°C之间。不同材料有其特定的最佳加工温度范围，需要根据材料供应商提供的技术数据来确定。
                </p>
              </div>
              <div className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                <h4 className="font-semibold mb-2">如何解决注塑件的缩水问题？</h4>
                <p className="text-gray-600 dark:text-gray-400">
                  缩水问题可以通过增加保压压力和时间、提高模具温度、优化浇口位置和尺寸等方法解决。此外，确保模具冷却系统的均匀性也非常重要。
                </p>
              </div>
              <div className={`p-4 rounded-lg ${isDark ? 'bg-gray-700' : 'bg-gray-50'}`}>
                <h4 className="font-semibold mb-2">注塑成型周期由哪些部分组成？</h4>
                <p className="text-gray-600 dark:text-gray-400">
                  注塑成型周期主要由注射时间、保压时间、冷却时间、开模时间和顶出时间组成。其中，冷却时间通常占整个周期的大部分，可以通过优化模具冷却系统来缩短。
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}